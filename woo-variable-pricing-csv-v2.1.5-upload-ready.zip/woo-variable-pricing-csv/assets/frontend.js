(function ($) {
  function initMeasurementPricing($form) {
    if (!$form.length || $form.data("wvpcMeasurementPricingReady")) {
      return;
    }

    $form.data("wvpcMeasurementPricingReady", true);

    var $summary = $form.closest(".summary");
    var $wrapper = $form.find(".wvpc-measurements");

    if (!$wrapper.length && $summary.length) {
      $wrapper = $summary.find(".wvpc-measurements").first();
    }

    if (!$wrapper.length || !window.wvpcFrontend) {
      return;
    }

    var productId = parseInt($wrapper.data("product-id"), 10) || 0;
    var timers = [];
    var request = null;
    var defaultPriceHtml = "";
    var activeBasePriceHtml = "";
    var defaultInlinePriceHtml = "";
    var lastVariationAttributes = {};
    var $measurementNote = $wrapper.find(".wvpc-measurements__note").first();
    var defaultMeasurementNote =
      String($measurementNote.data("default-note") || "").trim() ||
      ($measurementNote.text() || "").trim() ||
      "";

    function getWidthField() {
      return $form
        .find('input[name="wvpc_width_cm"], input[name="wvpc_width_mm"]')
        .first();
    }

    function getHeightField() {
      return $form
        .find('input[name="wvpc_height_cm"], input[name="wvpc_height_mm"]')
        .first();
    }

    function getVariationField() {
      var $field = $form.find('input[name="variation_id"]').first();

      if (!$field.length && $summary.length) {
        $field = $summary.find('input[name="variation_id"]').first();
      }

      return $field;
    }

    function getHiddenPriceField() {
      return $form.find('input[name="wvpc_calculated_price"]').first();
    }

    function getInlinePrice() {
      var $inlinePrice = $form.find(".wvpc-inline-price").first();

      if (!$inlinePrice.length && $summary.length) {
        $inlinePrice = $summary.find(".wvpc-inline-price").first();
      }

      return $inlinePrice;
    }

    function getInlinePriceValue() {
      return getInlinePrice().find(".wvpc-inline-price__value").first();
    }

    function getMeasurementNote() {
      var $note = $wrapper.find(".wvpc-measurements__note").first();

      if (!$note.length && $summary.length) {
        $note = $summary.find(".wvpc-measurements__note").first();
      }

      return $note;
    }

    function normalizeText(text) {
      return String(text || "").trim()
        .toLowerCase()
        .replace(/\s+/g, " ");
    }

    function placeMeasurementsAfterConfiguratorTitle() {
      var anchorText = "configura tu cortina a medida";
      var $anchor = $();

      $form.find("h1, h2, h3, h4, h5, h6, p, span, strong, legend, label").each(
        function () {
          var $candidate = $(this);

          if ($candidate.closest(".wvpc-measurements").length) {
            return;
          }

          if (normalizeText($candidate.text()).indexOf(anchorText) === -1) {
            return;
          }

          $anchor = $candidate;
          return false;
        }
      );

      if ($anchor.length && $anchor.closest("form").is($form)) {
        var $target = $anchor;

        if ($anchor.is("span, strong, label")) {
          var $blockContainer = $anchor.closest(
            "p, div, section, article, header, fieldset, h1, h2, h3, h4, h5, h6"
          );

          if (
            $blockContainer.length &&
            !$blockContainer.hasClass("wvpc-measurements") &&
            $blockContainer.closest("form").is($form)
          ) {
            $target = $blockContainer.first();
          }
        }

        $wrapper.insertAfter($target.first());
      }
    }

    function setMeasurementNote(state, message, useDefaultFallback) {
      var $note = getMeasurementNote();
      var text = String(message || "").trim();
      var shouldUseDefault = false !== useDefaultFallback;

      if (!$note.length) {
        return;
      }

      if (!text.length && shouldUseDefault) {
        text = defaultMeasurementNote;
      }

      $note.removeClass("is-ready is-loading is-error is-hidden");

      if (state) {
        $note.addClass("is-" + state);
      }

      if (!text.length) {
        $note.text("");
        $note.addClass("is-hidden");
        return;
      }

      $note.text(text);
    }

    function getPriceTargets() {
      var $targets = $summary.find(
        ".woocommerce-variation-price .price, .single_variation .price, p.price, span.price"
      );

      return $targets.filter(function () {
        return !$(this).closest(".wvpc-measurements, .wvpc-inline-price").length;
      });
    }

    function rememberBasePrice(html) {
      if (typeof html === "string" && html.length) {
        activeBasePriceHtml = html;

        if (!defaultPriceHtml) {
          defaultPriceHtml = html;
        }

        return;
      }

      var $targets = getPriceTargets();

      if (!$targets.length) {
        return;
      }

      var currentHtml = ($targets.first().html() || "").trim();

      if (!currentHtml.length) {
        return;
      }

      if (!defaultPriceHtml) {
        defaultPriceHtml = currentHtml;
      }

      activeBasePriceHtml = currentHtml;
    }

    function getFallbackPriceHtml() {
      if (!activeBasePriceHtml) {
        rememberBasePrice();
      }

      return activeBasePriceHtml || defaultPriceHtml || defaultInlinePriceHtml || "--";
    }

    function setInlinePriceState(state, html, message) {
      var $inlinePrice = getInlinePrice();
      var $inlinePriceValue = getInlinePriceValue();

      if (!$inlinePrice.length) {
        return;
      }

      $inlinePrice.removeClass("is-ready is-loading is-error");

      if (state) {
        $inlinePrice.addClass("is-" + state);
      }

      if (typeof html === "string" && (html || "").trim().length) {
        $inlinePriceValue.html(html);
      } else {
        $inlinePriceValue.html(getFallbackPriceHtml());
      }

      if (message && String(message || "").trim().length) {
        $inlinePrice.attr("title", message);
      } else {
        $inlinePrice.removeAttr("title");
      }
    }

    function updateDisplayedPrice(html, isCalculated) {
      var $targets = getPriceTargets();

      if (!$targets.length || !html) {
        return;
      }

      $targets.each(function () {
        $(this)
          .html(html)
          .toggleClass("wvpc-live-price", !!isCalculated);
      });
    }

    function restoreDisplayedPrice() {
      var basePriceHtml = getFallbackPriceHtml();

      if (basePriceHtml) {
        updateDisplayedPrice(basePriceHtml, false);
      }
    }

    function getMeasurementText($field) {
      if (!$field || !$field.length) {
        return "";
      }

      return String($field.val() || "").trim();
    }

    function hasMeasurementText(value) {
      var normalized = String(value || "").replace(",", ".");
      var parsed = parseFloat(normalized);

      return !!normalized.length && !window.isNaN(parsed) && parsed > 0;
    }

    function appendMeasurementRequestValue(data, dimension, $field, value) {
      var fieldName = String(($field && $field.attr("name")) || "");
      var usesMillimeters = fieldName.indexOf("_mm") !== -1;

      data[dimension + (usesMillimeters ? "_mm" : "_cm")] = value;
    }

    function mergeAttributes(target, source) {
      $.each(source || {}, function (name, value) {
        name = String(name || "").trim();
        value = String(value || "").trim();

        if (!name.length || name.indexOf("attribute_") !== 0 || !value.length) {
          return;
        }

        if (!Object.prototype.hasOwnProperty.call(target, name) || !String(target[name] || "").trim().length) {
          target[name] = value;
        }
      });

      return target;
    }

    function collectAttributes() {
      var attributes = {};

      $form.add($summary).find(':input[name^="attribute_"]').each(function () {
        var $input = $(this);
        var type = String($input.attr("type") || "").toLowerCase();
        var name = String($input.attr("name") || "");
        var value = String($input.val() || "").trim();

        if (!name.length) {
          return;
        }

        if ((type === "radio" || type === "checkbox") && !$input.prop("checked")) {
          return;
        }

        if (!value.length) {
          return;
        }

        attributes[name] = value;
      });

      mergeAttributes(attributes, lastVariationAttributes);

      return attributes;
    }

    function resetState(message) {
      var $hiddenPrice = getHiddenPriceField();

      if ($hiddenPrice.length) {
        $hiddenPrice.val("");
      }

      restoreDisplayedPrice();
      setInlinePriceState("", getFallbackPriceHtml(), message || "");
      setMeasurementNote("", message || defaultMeasurementNote);
    }

    function clearScheduledCalculations() {
      while (timers.length) {
        window.clearTimeout(timers.pop());
      }
    }

    function scheduleCalculation(delayMs) {
      clearScheduledCalculations();
      timers.push(
        window.setTimeout(calculatePrice, typeof delayMs === "number" ? delayMs : 250)
      );
    }

    function scheduleCalculationSequence(delays) {
      clearScheduledCalculations();

      $.each(delays || [250], function (_index, delay) {
        timers.push(window.setTimeout(calculatePrice, delay));
      });
    }

    function calculatePrice() {
      var $variationId = getVariationField();
      var $width = getWidthField();
      var $height = getHeightField();
      var $hiddenPrice = getHiddenPriceField();
      var variationId = parseInt($variationId.val(), 10) || 0;
      var width = getMeasurementText($width);
      var height = getMeasurementText($height);
      var attributes = collectAttributes();

      if (!variationId && !Object.keys(attributes).length) {
        resetState(wvpcFrontend.i18n.chooseVariation);
        return;
      }

      if (!hasMeasurementText(width) || !hasMeasurementText(height)) {
        resetState(wvpcFrontend.i18n.missingMeasurements);
        return;
      }

      setInlinePriceState("loading", getFallbackPriceHtml(), wvpcFrontend.i18n.loading);
      setMeasurementNote("loading", wvpcFrontend.i18n.loading);

      if (request && request.readyState !== 4) {
        request.abort();
      }

      var requestData = {
        action: "wvpc_calculate_price",
        nonce: wvpcFrontend.nonce,
        product_id: productId,
        variation_id: variationId,
        attributes: attributes,
      };

      appendMeasurementRequestValue(requestData, "width", $width, width);
      appendMeasurementRequestValue(requestData, "height", $height, height);

      request = $.ajax({
        url: wvpcFrontend.ajaxUrl,
        type: "POST",
        dataType: "json",
        data: requestData,
      })
        .done(function (response) {
          if (!response || !response.success || !response.data) {
            resetState(wvpcFrontend.i18n.placeholder);
            return;
          }

          if ($hiddenPrice.length) {
            $hiddenPrice.val(response.data.price || "");
          }

          updateDisplayedPrice(response.data.price_html || "", true);
          setInlinePriceState(
            "ready",
            response.data.price_html || "",
            response.data.message || ""
          );
          setMeasurementNote("", "", false);
        })
        .fail(function (xhr) {
          if (xhr && xhr.statusText === "abort") {
            return;
          }

          var message = wvpcFrontend.i18n.placeholder;

          if (
            xhr &&
            xhr.responseJSON &&
            xhr.responseJSON.data &&
            xhr.responseJSON.data.message
          ) {
            message = xhr.responseJSON.data.message;
          }

          if ($hiddenPrice.length) {
            $hiddenPrice.val("");
          }

          restoreDisplayedPrice();
          setInlinePriceState("error", getFallbackPriceHtml(), message);
          setMeasurementNote("error", message);
        });
    }

    placeMeasurementsAfterConfiguratorTitle();
    defaultInlinePriceHtml = (getInlinePriceValue().html() || "").trim() || "";
    rememberBasePrice();
    resetState(wvpcFrontend.i18n.chooseVariation);

    $form.on(
      "input change blur",
      'input[name="wvpc_width_cm"], input[name="wvpc_height_cm"], input[name="wvpc_width_mm"], input[name="wvpc_height_mm"]',
      function () {
        scheduleCalculationSequence([120, 320]);
      }
    );

    $form.on("change input click", ':input[name^="attribute_"]', function () {
      scheduleCalculationSequence([120, 360, 720]);
    });

    $form.on("click", "[data-value]", function () {
      scheduleCalculationSequence([180, 420, 780]);
    });

    $form.on(
      "woocommerce_variation_select_change check_variations update_variation_values woocommerce_update_variation_values woocommerce_variation_has_changed",
      function () {
        scheduleCalculationSequence([120, 320, 650]);
      }
    );

    $form.on("change input", 'input[name="variation_id"]', function () {
      scheduleCalculationSequence([80, 220]);
    });

    $form.on("found_variation show_variation", function (_event, variation) {
      lastVariationAttributes =
        variation && variation.attributes ? variation.attributes : {};

      if (variation && variation.price_html) {
        rememberBasePrice(variation.price_html);
        restoreDisplayedPrice();
        setInlinePriceState("", variation.price_html, "");
        setMeasurementNote("", defaultMeasurementNote);
      } else {
        rememberBasePrice();
        setInlinePriceState("", getFallbackPriceHtml(), "");
        setMeasurementNote("", defaultMeasurementNote);
      }

      scheduleCalculationSequence([80, 220]);
    });

    $form.on("hide_variation reset_data", function () {
      activeBasePriceHtml = defaultPriceHtml;
      lastVariationAttributes = {};
      resetState(wvpcFrontend.i18n.chooseVariation);
    });

    if (
      (parseInt(getVariationField().val(), 10) || Object.keys(collectAttributes()).length) &&
      hasMeasurementText(getMeasurementText(getWidthField())) &&
      hasMeasurementText(getMeasurementText(getHeightField()))
    ) {
      scheduleCalculationSequence([150, 380]);
    }
  }

  $(function () {
    $(".variations_form").each(function () {
      initMeasurementPricing($(this));
    });

    $(document.body).on("wc_variation_form", ".variations_form", function () {
      initMeasurementPricing($(this));
    });
  });
})(jQuery);
