<?php

if (!defined('ABSPATH')) {
    exit;
}

class WVPC_Admin {
    /**
     * Register admin hooks.
     *
     * @return void
     */
    public static function init() {
        add_action('add_meta_boxes', array(__CLASS__, 'register_meta_box'));
        add_action('post_edit_form_tag', array(__CLASS__, 'enable_file_upload_on_product_form'));
        add_action('save_post_product', array(__CLASS__, 'save_product_meta'), 20, 2);
        add_action('admin_notices', array(__CLASS__, 'render_notice'));
        add_action('admin_menu', array(__CLASS__, 'register_import_page'));
        add_action('admin_post_wvpc_import_csv', array(__CLASS__, 'handle_import_page_submission'));
        add_action('admin_post_wvpc_download_csv', array(__CLASS__, 'handle_csv_download'));

        // WooCommerce block-based product editor (WC 8+) saves via REST.
        // The plugin also exposes a dedicated admin page for CSV imports.
        add_action('woocommerce_rest_insert_product_object', array(__CLASS__, 'rest_save_product_settings'), 20, 2);
    }

    /**
     * Detect whether the new block-based product editor is currently active.
     *
     * @return bool
     */
    private static function is_block_editor_active() {
        if (!class_exists('Automattic\\WooCommerce\\Admin\\Features\\Features')) {
            return false;
        }

        return method_exists('Automattic\\WooCommerce\\Admin\\Features\\Features', 'is_enabled')
            && \Automattic\WooCommerce\Admin\Features\Features::is_enabled('product-block-editor');
    }

    /**
     * Save product settings when the product is saved via the REST API (block editor).
     *
     * File uploads are not supported in this flow; a notice is shown instead.
     *
     * @param \WC_Product      $product WooCommerce product.
     * @param \WP_REST_Request $request REST request.
     * @return void
     */
    public static function rest_save_product_settings($product, $request = null) {
        if (!($product instanceof WC_Product) || !$product->is_type('variable')) {
            return;
        }

        if (!is_object($request) || !method_exists($request, 'get_param')) {
            return;
        }

        $meta = $request->get_param('wvpc_settings');

        if (!is_array($meta)) {
            return;
        }

        $product_id = (int) $product->get_id();

        if (!current_user_can('edit_post', $product_id)) {
            return;
        }

        $defaults = WVPC_Pricing::get_product_settings($product_id);
        $settings = array(
            'enabled'        => (!empty($meta['enabled']) && 'yes' === sanitize_text_field($meta['enabled'])) ? 'yes' : 'no',
            'display_unit'   => array_key_exists('display_unit', $meta) ? WVPC_Pricing::sanitize_display_unit($meta['display_unit']) : $defaults['display_unit'],
            'csv_unit'       => array_key_exists('csv_unit', $meta) ? WVPC_Pricing::sanitize_csv_unit($meta['csv_unit']) : $defaults['csv_unit'],
            'min_width_mm'   => $defaults['min_width_mm'],
            'max_width_mm'   => $defaults['max_width_mm'],
            'width_step_mm'  => self::read_rest_measurement_setting_to_mm($meta, 'width_step', $defaults['width_step_mm']),
            'min_height_mm'  => $defaults['min_height_mm'],
            'max_height_mm'  => $defaults['max_height_mm'],
            'height_step_mm' => self::read_rest_measurement_setting_to_mm($meta, 'height_step', $defaults['height_step_mm']),
        );

        update_post_meta($product_id, WVPC_Pricing::META_ENABLED,   $settings['enabled']);
        update_post_meta($product_id, WVPC_Pricing::META_SETTINGS, $settings);

        if (array_key_exists('attribute_surcharges', $meta)) {
            WVPC_Pricing::save_attribute_surcharge_rules($product_id, $meta['attribute_surcharges']);
        }
    }

    /**
     * Register the meta box on products.
     *
     * @return void
     */
    public static function register_meta_box() {
        add_meta_box(
            'wvpc-measurement-pricing',
            __('Precio por medidas', 'woo-variable-pricing-csv'),
            array(__CLASS__, 'render_meta_box'),
            'product',
            'normal',
            'default'
        );
    }

    /**
     * Register a dedicated admin screen for CSV imports and settings.
     *
     * @return void
     */
    public static function register_import_page() {
        add_submenu_page(
            'edit.php?post_type=product',
            __('Importar CSV de tarifas', 'woo-variable-pricing-csv'),
            __('Importar CSV de tarifas', 'woo-variable-pricing-csv'),
            'edit_products',
            'wvpc-csv-import',
            array(__CLASS__, 'render_import_page')
        );
    }

    /**
     * Render plugin settings inside the product editor.
     *
     * @param \WP_Post $post Current post.
     * @return void
     */
    public static function render_meta_box($post) {
        $product = wc_get_product($post->ID);

        if (!$product || !$product->is_type('variable')) {
            echo '<p>' . esc_html__('Este configurador está pensado para productos variables de WooCommerce.', 'woo-variable-pricing-csv') . '</p>';
            return;
        }

        $settings    = WVPC_Pricing::get_product_settings($product->get_id());
        $rules       = WVPC_Pricing::get_rules($product->get_id());
        $surcharges  = WVPC_Pricing::get_attribute_surcharge_rules($product->get_id());
        $last_import = get_post_meta($product->get_id(), WVPC_Pricing::META_LAST_IMPORT, true);
        $stored_csv  = get_post_meta($product->get_id(), WVPC_Pricing::META_CSV_FILE, true);
        $sample_url  = WVPC_PLUGIN_URL . 'assets/sample-variable-prices.csv';

        if (self::is_block_editor_active()) {
            echo '<div class="notice notice-info inline"><p>'
                . esc_html__('Para evitar problemas con el editor de bloques, usa la pantalla dedicada del plugin para configurar la unidad visible, la unidad del CSV, las medidas e importar el CSV de tarifas de este producto.', 'woo-variable-pricing-csv')
                . '</p><p><a class="button button-primary" href="' . esc_url(self::get_import_page_url($product->get_id())) . '">'
                . esc_html__('Abrir configurador e importador CSV', 'woo-variable-pricing-csv')
                . '</a></p></div>';

            echo '<p><strong>' . esc_html__('Resumen actual', 'woo-variable-pricing-csv') . '</strong></p>';
            echo '<p>' . esc_html(
                sprintf(
                    /* translators: %d: rule count */
                    __('Reglas cargadas: %d', 'woo-variable-pricing-csv'),
                    count($rules)
                )
            ) . '</p>';
            echo '<p>' . esc_html(
                sprintf(
                    /* translators: %d: surcharge rule count */
                    __('Recargos por atributo configurados: %d', 'woo-variable-pricing-csv'),
                    count($surcharges)
                )
            ) . '</p>';

            if (is_array($last_import) && !empty($last_import['time'])) {
                echo '<p>' . esc_html(
                    sprintf(
                        /* translators: 1: import date, 2: filename, 3: saved rules, 4: errors */
                        __('Última importación: %1$s | Archivo: %2$s | Reglas guardadas: %3$d | Errores: %4$d', 'woo-variable-pricing-csv'),
                        date_i18n(get_option('date_format') . ' ' . get_option('time_format'), (int) $last_import['time']),
                        isset($last_import['filename']) ? (string) $last_import['filename'] : '-',
                        isset($last_import['rules']) ? (int) $last_import['rules'] : 0,
                        isset($last_import['errors']) ? (int) $last_import['errors'] : 0
                    )
                ) . '</p>';
            }

            self::render_stored_csv_download_link($product->get_id(), $stored_csv);

            echo '<p><a href="' . esc_url($sample_url) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Descargar CSV de ejemplo', 'woo-variable-pricing-csv') . '</a></p>';
            return;
        }

        wp_nonce_field('wvpc_save_product_' . $product->get_id(), 'wvpc_meta_nonce');

        echo '<p>' . esc_html__('El cliente introduce ancho y alto en la unidad visible elegida en la ficha del producto, mientras que el CSV puede importarse en milímetros o centímetros de forma independiente para la variación elegida.', 'woo-variable-pricing-csv') . '</p>';
        echo '<p>' . esc_html__('Los mínimos y máximos del ancho y del alto ya no se configuran aquí: se toman siempre del CSV importado.', 'woo-variable-pricing-csv') . '</p>';
        echo '<p><strong>' . esc_html__('Importante:', 'woo-variable-pricing-csv') . '</strong> ' . esc_html__('sube el CSV aquí y luego pulsa "Actualizar" o "Publicar" el producto para guardar las reglas.', 'woo-variable-pricing-csv') . '</p>';

        echo '<table class="form-table" role="presentation"><tbody>';

        echo '<tr>';
        echo '<th scope="row">' . esc_html__('Activar cálculo por medidas', 'woo-variable-pricing-csv') . '</th>';
        echo '<td><label>';
        echo '<input type="checkbox" name="wvpc_enabled" value="yes" ' . checked($settings['enabled'], 'yes', false) . ' />';
        echo ' ' . esc_html__('Este producto usará ancho y alto para calcular el precio final según la unidad visible seleccionada.', 'woo-variable-pricing-csv');
        echo '</label></td>';
        echo '</tr>';

        self::render_select_field_row(
            __('Unidad visible en la tienda', 'woo-variable-pricing-csv'),
            'wvpc_display_unit',
            isset($settings['display_unit']) ? $settings['display_unit'] : 'cm',
            array(
                'cm' => __('Centímetros (cm)', 'woo-variable-pricing-csv'),
                'mm' => __('Milímetros (mm)', 'woo-variable-pricing-csv'),
            ),
            __('La ficha del producto puede mostrarse en cm o mm. Los mínimos y máximos válidos se leerán siempre desde el CSV.', 'woo-variable-pricing-csv')
        );

        self::render_select_field_row(
            __('Unidad del CSV importado', 'woo-variable-pricing-csv'),
            'wvpc_csv_unit',
            isset($settings['csv_unit']) ? $settings['csv_unit'] : 'mm',
            array(
                'mm' => __('Milímetros (mm)', 'woo-variable-pricing-csv'),
                'cm' => __('Centímetros (cm)', 'woo-variable-pricing-csv'),
            ),
            __('Usa esta opción para indicar la unidad real del archivo. El plugin la aplicará a columnas heredadas como Widht y Height y también a archivos históricos con medidas exportadas en milímetros desde Excel.', 'woo-variable-pricing-csv')
        );

        self::render_number_field_row(
            __('Paso de ancho (cm)', 'woo-variable-pricing-csv'),
            'wvpc_width_step_mm',
            $settings['width_step_mm'],
            __('Ejemplo: 0,1 para cualquier milímetro, 0,5 para saltos equivalentes a 5 mm.', 'woo-variable-pricing-csv')
        );
        self::render_number_field_row(
            __('Paso de alto (cm)', 'woo-variable-pricing-csv'),
            'wvpc_height_step_mm',
            $settings['height_step_mm'],
            __('Ejemplo: 0,1 para cualquier milímetro, 0,5 para saltos equivalentes a 5 mm.', 'woo-variable-pricing-csv')
        );

        self::render_textarea_field_row(
            __('Recargos por atributo', 'woo-variable-pricing-csv'),
            'wvpc_attribute_surcharges',
            WVPC_Pricing::format_attribute_surcharge_rules($surcharges),
            __('Una regla por línea con formato atributo=valor:recargo. Ejemplos: pa_tejido=screen:25 o pa_tejido=screen:*1.15. Cada línea se guarda y se aplica como un recargo independiente, incluso si repite el mismo atributo y valor. Primero aplica los multiplicadores y después suma los recargos fijos.', 'woo-variable-pricing-csv')
        );

        echo '<tr>';
        echo '<th scope="row">' . esc_html__('CSV de tarifas', 'woo-variable-pricing-csv') . '</th>';
        echo '<td>';
        echo '<input type="file" name="wvpc_csv_file" accept=".csv,text/csv" />';
        echo '<p class="description">' . esc_html__('Sube una tabla de tarifas. El archivo se procesa al guardar el producto.', 'woo-variable-pricing-csv') . '</p>';
        echo '<p><a href="' . esc_url($sample_url) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Descargar CSV de ejemplo', 'woo-variable-pricing-csv') . '</a></p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row">' . esc_html__('Resumen actual', 'woo-variable-pricing-csv') . '</th>';
        echo '<td>';
        echo '<p>' . esc_html(
            sprintf(
                /* translators: %d: rule count */
                __('Reglas cargadas: %d', 'woo-variable-pricing-csv'),
                count($rules)
            )
        ) . '</p>';
        echo '<p>' . esc_html(
            sprintf(
                /* translators: %d: surcharge rule count */
                __('Recargos por atributo configurados: %d', 'woo-variable-pricing-csv'),
                count($surcharges)
            )
        ) . '</p>';

        if (is_array($last_import) && !empty($last_import['time'])) {
            echo '<p>' . esc_html(
                sprintf(
                    /* translators: 1: import date, 2: filename, 3: saved rules, 4: errors */
                    __('Última importación: %1$s | Archivo: %2$s | Reglas guardadas: %3$d | Errores: %4$d', 'woo-variable-pricing-csv'),
                    date_i18n(get_option('date_format') . ' ' . get_option('time_format'), (int) $last_import['time']),
                    isset($last_import['filename']) ? (string) $last_import['filename'] : '-',
                    isset($last_import['rules']) ? (int) $last_import['rules'] : 0,
                    isset($last_import['errors']) ? (int) $last_import['errors'] : 0
                )
            ) . '</p>';
        }

        self::render_stored_csv_download_link($product->get_id(), $stored_csv);

        echo '</td>';
        echo '</tr>';

        echo '</tbody></table>';

        echo '<hr />';
        echo '<p><strong>' . esc_html__('Columnas CSV soportadas', 'woo-variable-pricing-csv') . '</strong></p>';
        echo '<p><code>Widht</code>, <code>Height</code>, <code>Price</code>, <code>width_cm</code>, <code>height_cm</code>, <code>width_mm</code>, <code>height_mm</code>, <code>min_width_cm</code>, <code>max_width_cm</code>, <code>min_height_cm</code>, <code>max_height_cm</code>, <code>min_width_mm</code>, <code>max_width_mm</code>, <code>min_height_mm</code>, <code>max_height_mm</code>, <code>price_per_m2</code>, <code>base_price</code>, <code>min_price</code>, <code>variation_id</code>, <code>sku</code></p>';
        echo '<p>' . esc_html__('Si el CSV solo trae Widht, Height y Price, la misma tabla se aplicará a todas las variaciones del producto y esas columnas heredadas seguirán la unidad del CSV importado que elijas arriba. También se aceptan alias como ancho_cm, alto_cm, ancho_mm, alto_mm, precio, precio_m2, precio_base y precio_minimo. La ficha del producto puede mostrarse en cm o mm, pero el plugin conserva internamente los milímetros para no perder precisión ni compatibilidad con datos anteriores.', 'woo-variable-pricing-csv') . '</p>';
    }

    /**
     * Render the dedicated admin page for settings and CSV import.
     *
     * @return void
     */
    public static function render_import_page() {
        if (!current_user_can('edit_products')) {
            wp_die(esc_html__('No tienes permisos para acceder a esta pantalla.', 'woo-variable-pricing-csv'));
        }

        $product_id = isset($_GET['product_id']) ? absint(wp_unslash($_GET['product_id'])) : 0;
        $product    = $product_id ? wc_get_product($product_id) : false;

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('Importar CSV de tarifas', 'woo-variable-pricing-csv') . '</h1>';

        if (!$product_id || !$product || !$product->is_type('variable')) {
            echo '<div class="notice notice-warning"><p>' . esc_html__('Abre esta pantalla desde un producto variable concreto para importar su CSV de tarifas.', 'woo-variable-pricing-csv') . '</p></div>';
            echo '</div>';
            return;
        }

        $settings    = WVPC_Pricing::get_product_settings($product->get_id());
        $rules       = WVPC_Pricing::get_rules($product->get_id());
        $surcharges  = WVPC_Pricing::get_attribute_surcharge_rules($product->get_id());
        $last_import = get_post_meta($product->get_id(), WVPC_Pricing::META_LAST_IMPORT, true);
        $stored_csv  = get_post_meta($product->get_id(), WVPC_Pricing::META_CSV_FILE, true);
        $sample_url  = WVPC_PLUGIN_URL . 'assets/sample-variable-prices.csv';

        echo '<p><strong>' . esc_html__('Producto:', 'woo-variable-pricing-csv') . '</strong> ' . esc_html($product->get_name()) . ' (#' . (int) $product->get_id() . ')</p>';
        echo '<p><a href="' . esc_url(get_edit_post_link($product->get_id(), '')) . '">' . esc_html__('Volver a editar el producto', 'woo-variable-pricing-csv') . '</a></p>';
        echo '<p>' . esc_html__('Aquí puedes dejar separadas la unidad visible en tienda y la unidad real del CSV importado.', 'woo-variable-pricing-csv') . '</p>';
        echo '<p>' . esc_html__('Los mínimos y máximos válidos se tomarán siempre del CSV importado para este producto.', 'woo-variable-pricing-csv') . '</p>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" enctype="multipart/form-data">';
        wp_nonce_field('wvpc_import_csv_' . $product->get_id(), 'wvpc_import_csv_nonce');
        echo '<input type="hidden" name="action" value="wvpc_import_csv" />';
        echo '<input type="hidden" name="product_id" value="' . esc_attr((string) $product->get_id()) . '" />';

        echo '<table class="form-table" role="presentation"><tbody>';

        echo '<tr>';
        echo '<th scope="row">' . esc_html__('Activar cálculo por medidas', 'woo-variable-pricing-csv') . '</th>';
        echo '<td><label>';
        echo '<input type="checkbox" name="wvpc_enabled" value="yes" ' . checked($settings['enabled'], 'yes', false) . ' />';
        echo ' ' . esc_html__('Este producto usará ancho y alto para calcular el precio final según la unidad visible seleccionada.', 'woo-variable-pricing-csv');
        echo '</label></td>';
        echo '</tr>';

        self::render_select_field_row(
            __('Unidad visible en la tienda', 'woo-variable-pricing-csv'),
            'wvpc_display_unit',
            isset($settings['display_unit']) ? $settings['display_unit'] : 'cm',
            array(
                'cm' => __('Centímetros (cm)', 'woo-variable-pricing-csv'),
                'mm' => __('Milímetros (mm)', 'woo-variable-pricing-csv'),
            ),
            __('La ficha del producto puede mostrarse en cm o mm. Los mínimos y máximos válidos se leerán siempre desde el CSV.', 'woo-variable-pricing-csv')
        );

        self::render_select_field_row(
            __('Unidad del CSV importado', 'woo-variable-pricing-csv'),
            'wvpc_csv_unit',
            isset($settings['csv_unit']) ? $settings['csv_unit'] : 'mm',
            array(
                'mm' => __('Milímetros (mm)', 'woo-variable-pricing-csv'),
                'cm' => __('Centímetros (cm)', 'woo-variable-pricing-csv'),
            ),
            __('Usa esta opción para indicar la unidad real del archivo. El plugin la aplicará a columnas heredadas como Widht y Height y también a archivos históricos con medidas exportadas en milímetros desde Excel.', 'woo-variable-pricing-csv')
        );

        self::render_number_field_row(
            __('Paso de ancho (cm)', 'woo-variable-pricing-csv'),
            'wvpc_width_step_mm',
            $settings['width_step_mm'],
            __('Ejemplo: 0,1 para cualquier milímetro, 0,5 para saltos equivalentes a 5 mm.', 'woo-variable-pricing-csv')
        );
        self::render_number_field_row(
            __('Paso de alto (cm)', 'woo-variable-pricing-csv'),
            'wvpc_height_step_mm',
            $settings['height_step_mm'],
            __('Ejemplo: 0,1 para cualquier milímetro, 0,5 para saltos equivalentes a 5 mm.', 'woo-variable-pricing-csv')
        );

        self::render_textarea_field_row(
            __('Recargos por atributo', 'woo-variable-pricing-csv'),
            'wvpc_attribute_surcharges',
            WVPC_Pricing::format_attribute_surcharge_rules($surcharges),
            __('Una regla por línea con formato atributo=valor:recargo. Ejemplos: pa_tejido=screen:25 o pa_tejido=screen:*1.15. Cada línea se guarda y se aplica como un recargo independiente, incluso si repite el mismo atributo y valor. Primero aplica los multiplicadores y después suma los recargos fijos.', 'woo-variable-pricing-csv')
        );

        echo '<tr>';
        echo '<th scope="row">' . esc_html__('CSV de tarifas', 'woo-variable-pricing-csv') . '</th>';
        echo '<td>';
        echo '<input type="file" name="wvpc_csv_file" accept=".csv,text/csv" />';
        echo '<p class="description">' . esc_html__('Sube una tabla de tarifas. El archivo se procesa al guardar este formulario.', 'woo-variable-pricing-csv') . '</p>';
        echo '<p><a href="' . esc_url($sample_url) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Descargar CSV de ejemplo', 'woo-variable-pricing-csv') . '</a></p>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th scope="row">' . esc_html__('Resumen actual', 'woo-variable-pricing-csv') . '</th>';
        echo '<td>';
        echo '<p>' . esc_html(
            sprintf(
                /* translators: %d: rule count */
                __('Reglas cargadas: %d', 'woo-variable-pricing-csv'),
                count($rules)
            )
        ) . '</p>';
        echo '<p>' . esc_html(
            sprintf(
                /* translators: %d: surcharge rule count */
                __('Recargos por atributo configurados: %d', 'woo-variable-pricing-csv'),
                count($surcharges)
            )
        ) . '</p>';

        if (is_array($last_import) && !empty($last_import['time'])) {
            echo '<p>' . esc_html(
                sprintf(
                    /* translators: 1: import date, 2: filename, 3: saved rules, 4: errors */
                    __('Última importación: %1$s | Archivo: %2$s | Reglas guardadas: %3$d | Errores: %4$d', 'woo-variable-pricing-csv'),
                    date_i18n(get_option('date_format') . ' ' . get_option('time_format'), (int) $last_import['time']),
                    isset($last_import['filename']) ? (string) $last_import['filename'] : '-',
                    isset($last_import['rules']) ? (int) $last_import['rules'] : 0,
                    isset($last_import['errors']) ? (int) $last_import['errors'] : 0
                )
            ) . '</p>';
        }

        self::render_stored_csv_download_link($product->get_id(), $stored_csv);

        echo '</td>';
        echo '</tr>';
        echo '</tbody></table>';

        submit_button(__('Guardar configuración e importar CSV', 'woo-variable-pricing-csv'));
        echo '</form>';
        echo '</div>';
    }

    /**
     * Handle dedicated CSV import page submissions.
     *
     * @return void
     */
    public static function handle_import_page_submission() {
        $product_id = isset($_POST['product_id']) ? absint(wp_unslash($_POST['product_id'])) : 0;

        if (!$product_id) {
            wp_die(esc_html__('Producto no válido.', 'woo-variable-pricing-csv'));
        }

        if (!current_user_can('edit_post', $product_id)) {
            wp_die(esc_html__('No tienes permisos para editar este producto.', 'woo-variable-pricing-csv'));
        }

        check_admin_referer('wvpc_import_csv_' . $product_id, 'wvpc_import_csv_nonce');

        $product = wc_get_product($product_id);

        if (!$product || !$product->is_type('variable')) {
            self::set_notice('error', __('Este configurador está pensado para productos variables de WooCommerce.', 'woo-variable-pricing-csv'));
            wp_safe_redirect(self::get_import_page_url($product_id));
            exit;
        }

        $settings = self::get_validated_post_settings($product_id);

        if (is_wp_error($settings)) {
            self::set_notice('error', $settings->get_error_message());
            wp_safe_redirect(self::get_import_page_url($product_id));
            exit;
        }

        $attribute_surcharges = isset($_POST['wvpc_attribute_surcharges'])
            ? WVPC_Pricing::sanitize_attribute_surcharge_rules(wp_unslash($_POST['wvpc_attribute_surcharges']))
            : array();

        $result = self::apply_settings_and_optional_csv_import(
            $product_id,
            $product,
            $settings,
            isset($_FILES['wvpc_csv_file']) ? $_FILES['wvpc_csv_file'] : null,
            $attribute_surcharges
        );

        if (!is_wp_error($result) && empty($result['csv_imported'])) {
            self::set_notice('success', __('Configuración guardada correctamente.', 'woo-variable-pricing-csv'));
        }

        wp_safe_redirect(self::get_import_page_url($product_id));
        exit;
    }

    /**
     * Save product settings and optionally import the uploaded CSV.
     *
     * @param int      $post_id Product ID.
     * @param \WP_Post $post    Product post.
     * @return void
     */
    public static function save_product_meta($post_id, $post) {
        if (!$post instanceof WP_Post || 'product' !== $post->post_type) {
            return;
        }

        if (!isset($_POST['wvpc_meta_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wvpc_meta_nonce'])), 'wvpc_save_product_' . $post_id)) {
            return;
        }

        if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || wp_is_post_revision($post_id)) {
            return;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        $product = wc_get_product($post_id);

        if (!$product || !$product->is_type('variable')) {
            return;
        }

        $settings = self::get_validated_post_settings($post_id);

        if (is_wp_error($settings)) {
            self::set_notice('error', $settings->get_error_message());
            return;
        }

        $attribute_surcharges = isset($_POST['wvpc_attribute_surcharges'])
            ? WVPC_Pricing::sanitize_attribute_surcharge_rules(wp_unslash($_POST['wvpc_attribute_surcharges']))
            : array();

        self::apply_settings_and_optional_csv_import(
            $post_id,
            $product,
            $settings,
            isset($_FILES['wvpc_csv_file']) ? $_FILES['wvpc_csv_file'] : null,
            $attribute_surcharges
        );
    }

    /**
     * Ensure the edit product form accepts file uploads.
     *
     * @return void
     */
    public static function enable_file_upload_on_product_form() {
        global $post;

        if (!$post instanceof WP_Post || 'product' !== $post->post_type) {
            return;
        }

        echo ' enctype="multipart/form-data"';
    }

    /**
     * Render saved admin notices.
     *
     * @return void
     */
    public static function render_notice() {
        $user_id = get_current_user_id();

        if (!$user_id) {
            return;
        }

        $notice = get_transient(self::get_notice_key($user_id));

        if (!$notice || empty($notice['message'])) {
            return;
        }

        delete_transient(self::get_notice_key($user_id));

        $type = isset($notice['type']) ? sanitize_html_class($notice['type']) : 'success';

        echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible"><p>';
        echo wp_kses_post($notice['message']);
        echo '</p></div>';
    }

    /**
     * Render a numeric field row.
     *
     * @param string $label       Field label.
     * @param string $field_name  Field name.
     * @param int    $value       Field value.
     * @param string $description Help text.
     * @return void
     */
    private static function render_number_field_row($label, $field_name, $value, $description) {
        echo '<tr>';
        echo '<th scope="row"><label for="' . esc_attr($field_name) . '">' . esc_html($label) . '</label></th>';
        echo '<td>';
        echo '<input type="number" min="0.1" step="0.1" class="small-text" id="' . esc_attr($field_name) . '" name="' . esc_attr($field_name) . '" value="' . esc_attr(self::format_mm_as_cm_input($value)) . '" inputmode="decimal" />';
        echo '<p class="description">' . esc_html($description) . '</p>';
        echo '</td>';
        echo '</tr>';
    }

    /**
     * Render a textarea field row.
     *
     * @param string $label       Field label.
     * @param string $field_name  Field name.
     * @param string $value       Field value.
     * @param string $description Help text.
     * @return void
     */
    private static function render_textarea_field_row($label, $field_name, $value, $description) {
        echo '<tr>';
        echo '<th scope="row"><label for="' . esc_attr($field_name) . '">' . esc_html($label) . '</label></th>';
        echo '<td>';
        echo '<textarea class="large-text code" rows="5" id="' . esc_attr($field_name) . '" name="' . esc_attr($field_name) . '">' . esc_textarea((string) $value) . '</textarea>';
        echo '<p class="description">' . esc_html($description) . '</p>';
        echo '</td>';
        echo '</tr>';
    }

    /**
     * Render a select field row.
     *
     * @param string $label       Field label.
     * @param string $field_name  Field name.
     * @param string $value       Current value.
     * @param array  $options     Value => label pairs.
     * @param string $description Help text.
     * @return void
     */
    private static function render_select_field_row($label, $field_name, $value, $options, $description) {
        echo '<tr>';
        echo '<th scope="row"><label for="' . esc_attr($field_name) . '">' . esc_html($label) . '</label></th>';
        echo '<td>';
        echo '<select id="' . esc_attr($field_name) . '" name="' . esc_attr($field_name) . '">';

        foreach ((array) $options as $option_value => $option_label) {
            echo '<option value="' . esc_attr((string) $option_value) . '"' . selected((string) $value, (string) $option_value, false) . '>' . esc_html((string) $option_label) . '</option>';
        }

        echo '</select>';
        echo '<p class="description">' . esc_html($description) . '</p>';
        echo '</td>';
        echo '</tr>';
    }

    /**
     * Read and validate plugin settings from the classic admin form.
     *
     * @param int $product_id Product ID.
     * @return array|\WP_Error
     */
    private static function get_validated_post_settings($product_id = 0) {
        $defaults = $product_id > 0
            ? WVPC_Pricing::get_product_settings($product_id)
            : WVPC_Pricing::get_default_settings();

        $settings = array(
            'enabled'        => (!empty($_POST['wvpc_enabled']) && 'yes' === sanitize_text_field(wp_unslash($_POST['wvpc_enabled']))) ? 'yes' : 'no',
            'display_unit'   => isset($_POST['wvpc_display_unit']) ? WVPC_Pricing::sanitize_display_unit(wp_unslash($_POST['wvpc_display_unit'])) : $defaults['display_unit'],
            'csv_unit'       => isset($_POST['wvpc_csv_unit']) ? WVPC_Pricing::sanitize_csv_unit(wp_unslash($_POST['wvpc_csv_unit'])) : $defaults['csv_unit'],
            'min_width_mm'   => (int) $defaults['min_width_mm'],
            'max_width_mm'   => (int) $defaults['max_width_mm'],
            'width_step_mm'  => self::read_required_centimeters_to_mm('wvpc_width_step_mm', __('Paso de ancho', 'woo-variable-pricing-csv')),
            'min_height_mm'  => (int) $defaults['min_height_mm'],
            'max_height_mm'  => (int) $defaults['max_height_mm'],
            'height_step_mm' => self::read_required_centimeters_to_mm('wvpc_height_step_mm', __('Paso de alto', 'woo-variable-pricing-csv')),
        );

        foreach ($settings as $value) {
            if (is_wp_error($value)) {
                return $value;
            }
        }

        return $settings;
    }

    /**
     * Read a required measurement in centimeters from POST and convert it to mm.
     *
     * @param string $field Field name.
     * @param string $label Human-readable label.
     * @return int|\WP_Error
     */
    private static function read_required_centimeters_to_mm($field, $label) {
        if (!isset($_POST[$field])) {
            return new WP_Error(
                'wvpc_missing_measurement',
                sprintf(__('Falta el campo %s en el formulario.', 'woo-variable-pricing-csv'), $label)
            );
        }

        return self::validate_centimeters_to_mm(wp_unslash($_POST[$field]), $label);
    }

    /**
     * Convert an admin or REST measurement in centimeters to stored millimeters.
     *
     * @param mixed $value   Raw value in centimeters.
     * @param int   $default Default millimeter value.
     * @return int
     */
    private static function convert_centimeters_to_mm($value, $default) {
        $raw_value = trim((string) $value);

        if ('' === $raw_value) {
            return (int) $default;
        }

        $normalized = WVPC_Pricing::normalize_localized_number_string($raw_value);

        if (!is_numeric($normalized)) {
            return (int) $default;
        }

        $centimeters = (float) $normalized;
        $millimeters = $centimeters * 10;

        if ($centimeters <= 0 || abs($millimeters - round($millimeters)) > 0.00001) {
            return (int) $default;
        }

        return max(1, (int) round($millimeters));
    }

    /**
     * Validate a centimeter value entered in admin and convert it to stored mm.
     *
     * Only values that map exactly to whole millimeters are allowed.
     *
     * @param mixed  $value Raw value in centimeters.
     * @param string $label Human-readable field label.
     * @return int|\WP_Error
     */
    private static function validate_centimeters_to_mm($value, $label) {
        $raw_value = trim((string) $value);

        if ('' === $raw_value) {
            return new WP_Error(
                'wvpc_empty_measurement',
                sprintf(__('El campo %s es obligatorio.', 'woo-variable-pricing-csv'), $label)
            );
        }

        $normalized = WVPC_Pricing::normalize_localized_number_string($raw_value);

        if ('' === $normalized || !is_numeric($normalized)) {
            return new WP_Error(
                'wvpc_invalid_measurement',
                sprintf(__('El campo %s debe ser un número válido en centímetros.', 'woo-variable-pricing-csv'), $label)
            );
        }

        $centimeters = (float) $normalized;

        if ($centimeters <= 0) {
            return new WP_Error(
                'wvpc_non_positive_measurement',
                sprintf(__('El campo %s debe ser mayor que 0.', 'woo-variable-pricing-csv'), $label)
            );
        }

        $millimeters = $centimeters * 10;

        if (abs($millimeters - round($millimeters)) > 0.00001) {
            return new WP_Error(
                'wvpc_invalid_measurement_precision',
                sprintf(__('El campo %s debe usar saltos de 0,1 cm como máximo para conservar la equivalencia exacta con milímetros.', 'woo-variable-pricing-csv'), $label)
            );
        }

        return max(1, (int) round($millimeters));
    }

    /**
     * Read a measurement setting sent via REST in either cm or legacy mm.
     *
     * @param array  $meta     REST payload.
     * @param string $base_key Setting key without unit suffix.
     * @param int    $default  Default millimeter value.
     * @return int
     */
    private static function read_rest_measurement_setting_to_mm($meta, $base_key, $default) {
        $cm_keys = array(
            $base_key . '_cm',
            $base_key,
        );

        foreach ($cm_keys as $cm_key) {
            if (array_key_exists($cm_key, $meta)) {
                return self::convert_centimeters_to_mm($meta[$cm_key], $default);
            }
        }

        $legacy_mm_key = $base_key . '_mm';

        if (array_key_exists($legacy_mm_key, $meta)) {
            return max(1, absint($meta[$legacy_mm_key]));
        }

        return (int) $default;
    }

    /**
     * Convert a stored millimeter value to a centimeter input value.
     *
     * @param int|string $value_mm Stored measurement in millimeters.
     * @return string
     */
    private static function format_mm_as_cm_input($value_mm) {
        $cm_value = ((float) $value_mm) / 10;

        if (abs($cm_value - round($cm_value)) < 0.00001) {
            return (string) (int) round($cm_value);
        }

        return rtrim(rtrim(number_format($cm_value, 1, '.', ''), '0'), '.');
    }

    /**
     * Store an admin notice for the current user.
     *
     * @param string $type    Notice type.
     * @param string $message Notice message.
     * @return void
     */
    private static function set_notice($type, $message) {
        $user_id = get_current_user_id();

        if (!$user_id) {
            return;
        }

        set_transient(
            self::get_notice_key($user_id),
            array(
                'type'    => $type,
                'message' => $message,
            ),
            MINUTE_IN_SECONDS
        );
    }

    /**
     * Build the transient key used for notices.
     *
     * @param int $user_id User ID.
     * @return string
     */
    private static function get_notice_key($user_id) {
        return 'wvpc_notice_' . (int) $user_id;
    }

    /**
     * Return the dedicated importer URL for a product.
     *
     * @param int $product_id Product ID.
     * @return string
     */
    private static function get_import_page_url($product_id) {
        return add_query_arg(
            array(
                'post_type'  => 'product',
                'page'       => 'wvpc-csv-import',
                'product_id' => (int) $product_id,
            ),
            admin_url('edit.php')
        );
    }

    /**
     * Return the secure admin URL used to download a stored CSV.
     *
     * @param int $product_id Product ID.
     * @return string
     */
    private static function get_download_csv_url($product_id) {
        $url = add_query_arg(
            array(
                'action'     => 'wvpc_download_csv',
                'product_id' => (int) $product_id,
            ),
            admin_url('admin-post.php')
        );

        return wp_nonce_url($url, 'wvpc_download_csv_' . (int) $product_id);
    }

    /**
     * Render the secure CSV download link when a file is stored for the product.
     *
     * @param int   $product_id Product ID.
     * @param array $stored_csv Stored CSV metadata.
     * @return void
     */
    private static function render_stored_csv_download_link($product_id, $stored_csv) {
        if (!is_array($stored_csv) || empty($stored_csv['file'])) {
            return;
        }

        $filename = !empty($stored_csv['filename']) ? (string) $stored_csv['filename'] : basename((string) $stored_csv['file']);

        echo '<p><a href="' . esc_url(self::get_download_csv_url($product_id)) . '">' . esc_html(
            sprintf(
                /* translators: %s: stored CSV filename */
                __('Descargar CSV guardado en el servidor (%s)', 'woo-variable-pricing-csv'),
                $filename
            )
        ) . '</a></p>';
    }

    /**
     * Serve the stored CSV to authorized admins via WordPress.
     *
     * @return void
     */
    public static function handle_csv_download() {
        $product_id = isset($_GET['product_id']) ? absint(wp_unslash($_GET['product_id'])) : 0;

        if (!$product_id) {
            wp_die(esc_html__('Producto no válido.', 'woo-variable-pricing-csv'));
        }

        if (!current_user_can('edit_post', $product_id)) {
            wp_die(esc_html__('No tienes permisos para descargar este CSV.', 'woo-variable-pricing-csv'));
        }

        check_admin_referer('wvpc_download_csv_' . $product_id);

        $stored_csv = get_post_meta($product_id, WVPC_Pricing::META_CSV_FILE, true);

        if (!is_array($stored_csv) || empty($stored_csv['file'])) {
            wp_die(esc_html__('No hay un CSV guardado para este producto.', 'woo-variable-pricing-csv'));
        }

        $upload_dir     = wp_get_upload_dir();
        $protected_root = isset($upload_dir['basedir']) ? wp_normalize_path(trailingslashit($upload_dir['basedir']) . 'wvpc-csv') : '';
        $file_path      = wp_normalize_path((string) $stored_csv['file']);

        if (
            '' === $protected_root ||
            '' === $file_path ||
            0 !== strpos($file_path, trailingslashit($protected_root)) ||
            !file_exists($file_path) ||
            !is_file($file_path) ||
            !is_readable($file_path)
        ) {
            wp_die(esc_html__('El CSV guardado no está disponible para descarga.', 'woo-variable-pricing-csv'));
        }

        $filename = !empty($stored_csv['filename']) ? sanitize_file_name((string) $stored_csv['filename']) : basename($file_path);
        $filename = str_replace(array('"', "\r", "\n"), '', $filename);

        $file_size = filesize($file_path);

        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        if (false !== $file_size) {
            header('Content-Length: ' . (string) $file_size);
        }

        readfile($file_path);
        exit;
    }

    /**
     * Save settings and optionally import a CSV file.
     *
     * @param int              $post_id        Product ID.
     * @param \WC_Product      $product        Variable product.
     * @param array            $settings       Normalized settings.
     * @param array|null       $uploaded_file  Uploaded file array.
     * @param array|null       $attribute_surcharges Attribute surcharge rules.
     * @return array|\WP_Error
     */
    private static function apply_settings_and_optional_csv_import($post_id, $product, $settings, $uploaded_file = null, $attribute_surcharges = null) {
        $previous_csv = get_post_meta($post_id, WVPC_Pricing::META_CSV_FILE, true);
        $saved_csv    = null;
        $filename     = '';
        $is_reimport  = false;

        update_post_meta($post_id, WVPC_Pricing::META_ENABLED, $settings['enabled']);
        update_post_meta($post_id, WVPC_Pricing::META_SETTINGS, $settings);

        if (null !== $attribute_surcharges) {
            WVPC_Pricing::save_attribute_surcharge_rules($post_id, $attribute_surcharges);
        }

        if (!is_array($uploaded_file) || empty($uploaded_file['name'])) {
            if (
                !is_array($previous_csv) ||
                empty($previous_csv['file']) ||
                !file_exists((string) $previous_csv['file']) ||
                !is_readable((string) $previous_csv['file'])
            ) {
                return array(
                    'csv_imported' => false,
                );
            }

            $saved_csv   = $previous_csv;
            $filename    = !empty($previous_csv['filename']) ? sanitize_file_name((string) $previous_csv['filename']) : basename((string) $previous_csv['file']);
            $is_reimport = true;
        } else {
            $upload_error = isset($uploaded_file['error']) ? (int) $uploaded_file['error'] : UPLOAD_ERR_NO_FILE;

            if (UPLOAD_ERR_OK !== $upload_error) {
                self::set_notice('error', __('No se pudo subir el CSV. Revisa el tamaño del archivo e inténtalo de nuevo.', 'woo-variable-pricing-csv'));
                return new WP_Error('wvpc_csv_upload_error', __('No se pudo subir el CSV. Revisa el tamaño del archivo e inténtalo de nuevo.', 'woo-variable-pricing-csv'));
            }

            if (empty($uploaded_file['tmp_name']) || !is_uploaded_file($uploaded_file['tmp_name'])) {
                self::set_notice('error', __('El archivo CSV temporal no está disponible para procesarlo.', 'woo-variable-pricing-csv'));
                return new WP_Error('wvpc_csv_tmp_missing', __('El archivo CSV temporal no está disponible para procesarlo.', 'woo-variable-pricing-csv'));
            }

            $filename  = isset($uploaded_file['name']) ? sanitize_file_name(wp_unslash($uploaded_file['name'])) : '';
            $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

            if ('csv' !== $extension) {
                self::set_notice('error', __('El archivo debe tener extensión .csv.', 'woo-variable-pricing-csv'));
                return new WP_Error('wvpc_csv_extension', __('El archivo debe tener extensión .csv.', 'woo-variable-pricing-csv'));
            }

            $saved_csv = self::store_uploaded_csv($post_id, $uploaded_file);

            if (is_wp_error($saved_csv)) {
                self::set_notice('error', $saved_csv->get_error_message());
                return $saved_csv;
            }
        }

        $result = WVPC_Pricing::parse_csv_rules($product, $saved_csv['file'], $filename);

        if (is_wp_error($result)) {
            if (!$is_reimport) {
                self::delete_stored_csv_file($saved_csv);
            }
            self::set_notice('error', $result->get_error_message());
            return $result;
        }

        $settings = WVPC_Pricing::derive_settings_from_rules($result['rules'], $settings);

        update_post_meta($post_id, WVPC_Pricing::META_ENABLED, $settings['enabled']);
        update_post_meta($post_id, WVPC_Pricing::META_SETTINGS, $settings);
        update_post_meta($post_id, WVPC_Pricing::META_CSV_FILE, $saved_csv);
        update_post_meta($post_id, WVPC_Pricing::META_RULES, $result['rules']);
        update_post_meta(
            $post_id,
            WVPC_Pricing::META_LAST_IMPORT,
            array(
                'time'     => time(),
                'filename' => $filename,
                'rules'    => count($result['rules']),
                'errors'   => $result['errors'],
            )
        );

        if (
            !$is_reimport &&
            is_array($previous_csv) &&
            !empty($previous_csv['file']) &&
            (!isset($saved_csv['file']) || (string) $previous_csv['file'] !== (string) $saved_csv['file'])
        ) {
            self::delete_stored_csv_file($previous_csv);
        }

        $message = $is_reimport
            ? sprintf(
                /* translators: 1: processed rows, 2: saved rules, 3: errors */
                __('CSV guardado reimportado. Filas leídas: %1$d. Reglas guardadas: %2$d. Errores: %3$d.', 'woo-variable-pricing-csv'),
                (int) $result['processed'],
                count($result['rules']),
                (int) $result['errors']
            )
            : sprintf(
                /* translators: 1: processed rows, 2: saved rules, 3: errors */
                __('CSV procesado. Filas leídas: %1$d. Reglas guardadas: %2$d. Errores: %3$d.', 'woo-variable-pricing-csv'),
                (int) $result['processed'],
                count($result['rules']),
                (int) $result['errors']
            );

        if (!empty($result['error_messages'])) {
            $preview_errors = array_slice($result['error_messages'], 0, 5);
            $message       .= '<br />' . esc_html__('Resumen de errores:', 'woo-variable-pricing-csv') . '<br />- ' . implode('<br />- ', array_map('esc_html', $preview_errors));

            if (count($result['error_messages']) > 5) {
                $message .= '<br />' . esc_html__('Hay más errores en el CSV que no se muestran en este aviso.', 'woo-variable-pricing-csv');
            }
        }

        self::set_notice($result['errors'] > 0 ? 'warning' : 'success', $message);

        return array(
            'csv_imported' => true,
            'result'       => $result,
        );
    }

    /**
     * Save the uploaded CSV in a protected subdirectory of WordPress uploads.
     *
     * The directory is protected with an .htaccess (deny all) and an index.php,
     * and uploaded files are renamed to unpredictable names to reduce exposure
     * on servers that ignore .htaccess (for example, plain Nginx setups).
     *
     * @param int   $post_id Product ID.
     * @param array $file    Uploaded file array.
     * @return array|\WP_Error
     */
    private static function store_uploaded_csv($post_id, $file) {
        if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return new WP_Error('wvpc_csv_missing_tmp', __('El archivo CSV temporal no está disponible para guardarlo en el servidor.', 'woo-variable-pricing-csv'));
        }

        if (!function_exists('wp_handle_upload')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        $protected_dir = self::ensure_protected_csv_directory();

        if (is_wp_error($protected_dir)) {
            return $protected_dir;
        }

        // Override the upload path to our protected subdirectory.
        $subdir_filter = function ($dirs) use ($protected_dir) {
            $dirs['path']   = $protected_dir['path'];
            $dirs['url']    = $protected_dir['url'];
            $dirs['subdir'] = '/wvpc-csv';
            return $dirs;
        };

        add_filter('upload_dir', $subdir_filter);

        $upload = wp_handle_upload(
            $file,
            array(
                'test_form' => false,
                'mimes'     => array(
                    'csv' => 'text/csv',
                    'txt' => 'text/plain',
                ),
                'unique_filename_callback' => function ($dir, $name, $ext) use ($post_id) {
                    unset($dir, $name);

                    return 'wvpc-' . md5($post_id . '|' . wp_generate_uuid4() . '|' . microtime(true)) . $ext;
                },
            )
        );

        remove_filter('upload_dir', $subdir_filter);

        if (!is_array($upload) || !empty($upload['error']) || empty($upload['file']) || empty($upload['url'])) {
            return new WP_Error('wvpc_csv_store_failed', __('No se pudo guardar el CSV en la carpeta de uploads de WordPress.', 'woo-variable-pricing-csv'));
        }

        return array(
            'post_id'   => (int) $post_id,
            'filename'  => isset($file['name']) ? sanitize_file_name(wp_unslash($file['name'])) : basename($upload['file']),
            'file'      => $upload['file'],
            'type'      => isset($upload['type']) ? $upload['type'] : 'text/csv',
            'saved_at'  => time(),
        );
    }

    /**
     * Create (if needed) and return the path and URL of a web-protected CSV directory.
     *
     * The directory contains an .htaccess that denies direct HTTP access and an
     * index.php silence file so directory listings are also blocked. Nginx
     * installations still need a server rule to deny direct access to this path.
     *
     * @return array|\WP_Error  Array with 'path' and 'url' keys on success.
     */
    private static function ensure_protected_csv_directory() {
        $upload_dir = wp_upload_dir();

        if (!empty($upload_dir['error'])) {
            return new WP_Error('wvpc_upload_dir', $upload_dir['error']);
        }

        $dir_path = trailingslashit($upload_dir['basedir']) . 'wvpc-csv';
        $dir_url  = trailingslashit($upload_dir['baseurl']) . 'wvpc-csv';

        if (!file_exists($dir_path)) {
            wp_mkdir_p($dir_path);
        }

        if (!is_dir($dir_path) || !wp_is_writable($dir_path)) {
            return new WP_Error('wvpc_csv_dir_unwritable', __('No se pudo crear o escribir en el directorio protegido para CSVs.', 'woo-variable-pricing-csv'));
        }

        // Deny direct HTTP access via Apache / LiteSpeed.
        $htaccess = $dir_path . '/.htaccess';
        if (!file_exists($htaccess)) {
            file_put_contents($htaccess, "Options -Indexes
Deny from all
");
        }

        // Silence index for servers that ignore .htaccess.
        $index = $dir_path . '/index.php';
        if (!file_exists($index)) {
            file_put_contents($index, '<?php // Silence is golden.' . PHP_EOL);
        }

        return array(
            'path' => $dir_path,
            'url'  => $dir_url,
        );
    }

    /**
     * Delete a stored CSV file from uploads.
     *
     * @param array $stored_csv Stored CSV metadata.
     * @return void
     */
    private static function delete_stored_csv_file($stored_csv) {
        if (!is_array($stored_csv) || empty($stored_csv['file'])) {
            return;
        }

        $file_path = (string) $stored_csv['file'];

        if ('' === $file_path || !file_exists($file_path) || !is_file($file_path)) {
            return;
        }

        if (function_exists('wp_delete_file')) {
            wp_delete_file($file_path);
            return;
        }

        @unlink($file_path);
    }
}
