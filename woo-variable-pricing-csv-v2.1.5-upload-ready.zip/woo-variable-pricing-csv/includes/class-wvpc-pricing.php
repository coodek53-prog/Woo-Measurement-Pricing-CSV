<?php

if (!defined('ABSPATH')) {
    exit;
}

class WVPC_Pricing {
    const META_ENABLED = '_wvpc_enabled';
    const META_SETTINGS = '_wvpc_measure_settings';
    const META_RULES = '_wvpc_pricing_rules';
    const META_LAST_IMPORT = '_wvpc_last_import_summary';
    const META_CSV_FILE = '_wvpc_csv_file';
    const META_ATTRIBUTE_SURCHARGES = '_wvpc_attribute_surcharges';
    const ORDER_META_DATA    = '_wvpc_measurement_data';
    const ORDER_META_WIDTH   = '_wvpc_width_mm';
    const ORDER_META_HEIGHT  = '_wvpc_height_mm';
    const ORDER_META_RATE    = '_wvpc_rate_label';
    const ORDER_META_SURCHARGES = '_wvpc_surcharge_label';

    /**
     * Register frontend and cart hooks.
     *
     * @return void
     */
    public static function init() {
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_assets'));
        add_action('woocommerce_before_variations_form', array(__CLASS__, 'render_measure_fields'), 15);
        add_action('woocommerce_before_add_to_cart_quantity', array(__CLASS__, 'render_inline_price_panel'), 5);
        add_filter('woocommerce_add_to_cart_validation', array(__CLASS__, 'validate_add_to_cart'), 10, 6);
        add_filter('woocommerce_add_cart_item_data', array(__CLASS__, 'add_cart_item_data'), 10, 3);
        add_filter('woocommerce_get_item_data', array(__CLASS__, 'get_cart_item_display_data'), 10, 2);
        add_action('woocommerce_before_calculate_totals', array(__CLASS__, 'apply_cart_item_prices'));
        add_action('woocommerce_checkout_create_order_line_item', array(__CLASS__, 'add_order_item_meta'), 10, 4);
        add_action('wp_ajax_wvpc_calculate_price', array(__CLASS__, 'ajax_calculate_price'));
        add_action('wp_ajax_nopriv_wvpc_calculate_price', array(__CLASS__, 'ajax_calculate_price'));

        add_filter('woocommerce_order_item_display_meta_key', array(__CLASS__, 'translate_order_item_meta_key'), 10, 3);
        add_filter('woocommerce_order_item_display_meta_value', array(__CLASS__, 'translate_order_item_meta_value'), 10, 3);
        add_filter('woocommerce_hidden_order_itemmeta', array(__CLASS__, 'hide_internal_order_item_meta'));
    }

    /**
     * Translate internal meta keys to human-readable labels in the order view.
     *
     * @param string                    $display_key Meta key shown to the user.
     * @param object                    $meta        Meta object.
     * @param \WC_Order_Item_Product   $item        Order item.
     * @return string
     */
    public static function translate_order_item_meta_key($display_key, $meta, $item) {
        $labels = array(
            self::ORDER_META_WIDTH  => __('Ancho', 'woo-variable-pricing-csv'),
            self::ORDER_META_HEIGHT => __('Alto', 'woo-variable-pricing-csv'),
            self::ORDER_META_RATE   => __('Tarifa aplicada', 'woo-variable-pricing-csv'),
            self::ORDER_META_SURCHARGES => __('Ajustes por atributo', 'woo-variable-pricing-csv'),
        );

        return isset($labels[$display_key]) ? $labels[$display_key] : $display_key;
    }

    /**
     * Translate stored internal measurement meta values into the configured display unit.
     *
     * @param string                  $display_value Meta value shown to the user.
     * @param object                  $meta          Meta object.
     * @param \WC_Order_Item_Product  $item          Order item.
     * @return string
     */
    public static function translate_order_item_meta_value($display_value, $meta, $item) {
        $meta_key = (is_object($meta) && isset($meta->key)) ? (string) $meta->key : '';

        if (!in_array($meta_key, array(self::ORDER_META_WIDTH, self::ORDER_META_HEIGHT), true)) {
            return $display_value;
        }

        $measurement_mm = self::normalize_stored_order_measurement_to_mm(
            (is_object($meta) && isset($meta->value)) ? $meta->value : $display_value
        );

        if ($measurement_mm < 1) {
            return $display_value;
        }

        return self::format_measurement_with_unit($measurement_mm, self::get_order_item_display_unit($item));
    }

    /**
     * Hide the raw JSON data key from the order admin UI.
     *
     * @param array $keys Already-hidden keys.
     * @return array
     */
    public static function hide_internal_order_item_meta($keys) {
        $keys[] = self::ORDER_META_DATA;
        return $keys;
    }

    /**
     * Default settings for measurement pricing.
     *
     * @return array
     */
    public static function get_default_settings() {
        return array(
            'enabled'        => 'no',
            'display_unit'   => 'cm',
            'csv_unit'       => 'mm',
            'min_width_mm'   => 1,
            'max_width_mm'   => 10000,
            'width_step_mm'  => 1,
            'min_height_mm'  => 1,
            'max_height_mm'  => 10000,
            'height_step_mm' => 1,
        );
    }

    /**
     * Return product settings merged with defaults.
     *
     * @param int $product_id Product ID.
     * @return array
     */
    public static function get_product_settings($product_id) {
        $product_id = self::normalize_product_id($product_id);
        $defaults   = self::get_default_settings();
        $stored     = get_post_meta($product_id, self::META_SETTINGS, true);
        $settings   = is_array($stored) ? wp_parse_args($stored, $defaults) : $defaults;
        $enabled    = get_post_meta($product_id, self::META_ENABLED, true);

        $settings['enabled'] = ('yes' === $enabled || 'yes' === $settings['enabled']) ? 'yes' : 'no';
        $settings['display_unit'] = self::sanitize_display_unit(isset($settings['display_unit']) ? $settings['display_unit'] : $defaults['display_unit']);
        $settings['csv_unit'] = self::sanitize_csv_unit(isset($settings['csv_unit']) ? $settings['csv_unit'] : $defaults['csv_unit']);

        foreach (array('min_width_mm', 'max_width_mm', 'width_step_mm', 'min_height_mm', 'max_height_mm', 'height_step_mm') as $key) {
            $settings[$key] = absint($settings[$key]);

            if ($settings[$key] < 1) {
                $settings[$key] = (int) $defaults[$key];
            }
        }

        if ($settings['max_width_mm'] < $settings['min_width_mm']) {
            $settings['max_width_mm'] = $settings['min_width_mm'];
        }

        if ($settings['max_height_mm'] < $settings['min_height_mm']) {
            $settings['max_height_mm'] = $settings['min_height_mm'];
        }

        $rules = self::get_rules($product_id);

        if (!empty($rules)) {
            $settings = self::derive_settings_from_rules($rules, $settings);
        }

        return $settings;
    }

    /**
     * Check whether measurement pricing is enabled for a product.
     *
     * @param int $product_id Product ID.
     * @return bool
     */
    public static function is_enabled_for_product($product_id) {
        $settings = self::get_product_settings($product_id);

        return 'yes' === $settings['enabled'];
    }

    /**
     * Return stored pricing rules.
     *
     * @param int $product_id Product ID.
     * @return array
     */
    public static function get_rules($product_id) {
        $product_id = self::normalize_product_id($product_id);
        $rules      = get_post_meta($product_id, self::META_RULES, true);

        return is_array($rules) ? array_values($rules) : array();
    }

    /**
     * Return attribute surcharge rules saved for the product.
     *
     * @param int $product_id Product ID.
     * @return array
     */
    public static function get_attribute_surcharge_rules($product_id) {
        $product_id = self::normalize_product_id($product_id);
        $rules      = get_post_meta($product_id, self::META_ATTRIBUTE_SURCHARGES, true);

        return self::sanitize_attribute_surcharge_rules($rules);
    }

    /**
     * Save normalized attribute surcharge rules.
     *
     * @param int          $product_id Product ID.
     * @param string|array $raw_rules  Raw rules from admin or REST.
     * @return array Saved normalized rules.
     */
    public static function save_attribute_surcharge_rules($product_id, $raw_rules) {
        $product_id = self::normalize_product_id($product_id);
        $rules      = self::sanitize_attribute_surcharge_rules($raw_rules);

        if (empty($rules)) {
            delete_post_meta($product_id, self::META_ATTRIBUTE_SURCHARGES);
            return array();
        }

        update_post_meta($product_id, self::META_ATTRIBUTE_SURCHARGES, $rules);

        return $rules;
    }

    /**
     * Normalize surcharge rules from a textarea or structured REST payload.
     *
     * Supported textarea formats:
     * - pa_mecanismo=motorizado:25
     * - pa_mecanismo=motorizado:*1.15
     * - pa_mecanismo;motorizado;25
     *
     * @param string|array $raw_rules Raw rules.
     * @return array
     */
    public static function sanitize_attribute_surcharge_rules($raw_rules) {
        $rules = array();

        if (is_string($raw_rules)) {
            $lines = preg_split('/\r\n|\r|\n/', wp_unslash($raw_rules));

            foreach ($lines as $line) {
                $line = trim((string) $line);

                if ('' === $line || 0 === strpos($line, '#')) {
                    continue;
                }

                $rule = self::parse_attribute_surcharge_line($line);

                if (!empty($rule)) {
                    $rules[] = $rule;
                }
            }

            return self::deduplicate_attribute_surcharge_rules($rules);
        }

        if (!is_array($raw_rules)) {
            return array();
        }

        foreach ($raw_rules as $raw_rule) {
            if (!is_array($raw_rule)) {
                continue;
            }

            $attribute = isset($raw_rule['attribute']) ? $raw_rule['attribute'] : '';
            $value     = isset($raw_rule['value']) ? $raw_rule['value'] : '';
            $amount    = isset($raw_rule['amount']) ? $raw_rule['amount'] : '';
            $mode      = isset($raw_rule['mode']) ? $raw_rule['mode'] : '';

            if ('' === trim((string) $attribute) && !empty($raw_rule['attribute_label'])) {
                $attribute = $raw_rule['attribute_label'];
            }

            if ('' === trim((string) $value) && !empty($raw_rule['value_label'])) {
                $value = $raw_rule['value_label'];
            }

            if ('' === trim((string) $amount) && isset($raw_rule['multiplier'])) {
                $amount = $raw_rule['multiplier'];
            }

            $rule = self::normalize_attribute_surcharge_rule($attribute, $value, $amount, $mode);

            if (!empty($rule)) {
                $rules[] = $rule;
            }
        }

        return self::deduplicate_attribute_surcharge_rules($rules);
    }

    /**
     * Convert normalized surcharge rules to textarea text.
     *
     * @param array $rules Stored rules.
     * @return string
     */
    public static function format_attribute_surcharge_rules($rules) {
        $rules = self::sanitize_attribute_surcharge_rules($rules);
        $lines = array();

        foreach ($rules as $rule) {
            $attribute = !empty($rule['attribute_label'])
                ? (string) $rule['attribute_label']
                : preg_replace('/^attribute_/', '', (string) $rule['attribute']);
            $value = !empty($rule['value_label']) ? (string) $rule['value_label'] : (string) $rule['value'];

            $mode = self::sanitize_attribute_surcharge_mode(isset($rule['mode']) ? $rule['mode'] : 'fixed');
            $amount = ('multiplier' === $mode)
                ? '*' . self::format_localized_decimal_text((float) $rule['amount'], 4)
                : (function_exists('wc_format_localized_price')
                    ? wc_format_localized_price((float) $rule['amount'])
                    : (string) (float) $rule['amount']);

            $lines[] = sprintf('%1$s=%2$s:%3$s', $attribute, $value, $amount);
        }

        return implode("\n", $lines);
    }

    /**
     * Derive frontend measurement limits from imported rules.
     *
     * @param array $rules            Imported rules.
     * @param array $current_settings Current saved settings.
     * @return array
     */
    public static function derive_settings_from_rules($rules, $current_settings) {
        if (empty($rules) || !is_array($rules)) {
            return $current_settings;
        }

        $min_widths  = array();
        $max_widths  = array();
        $min_heights = array();
        $max_heights = array();

        foreach ($rules as $rule) {
            if (!is_array($rule)) {
                continue;
            }

            $min_widths[]  = isset($rule['min_width_mm']) ? (int) $rule['min_width_mm'] : 0;
            $max_widths[]  = isset($rule['max_width_mm']) ? (int) $rule['max_width_mm'] : 0;
            $min_heights[] = isset($rule['min_height_mm']) ? (int) $rule['min_height_mm'] : 0;
            $max_heights[] = isset($rule['max_height_mm']) ? (int) $rule['max_height_mm'] : 0;
        }

        $min_widths  = array_filter($min_widths);
        $max_widths  = array_filter($max_widths);
        $min_heights = array_filter($min_heights);
        $max_heights = array_filter($max_heights);

        if (empty($min_widths) || empty($max_widths) || empty($min_heights) || empty($max_heights)) {
            return $current_settings;
        }

        $current_settings['min_width_mm']  = min($min_widths);
        $current_settings['max_width_mm']  = max($max_widths);
        $current_settings['min_height_mm'] = min($min_heights);
        $current_settings['max_height_mm'] = max($max_heights);

        return $current_settings;
    }

    /**
     * Enqueue frontend assets only when needed.
     *
     * @return void
     */
    public static function enqueue_assets() {
        if (!function_exists('is_product') || !is_product()) {
            return;
        }

        $product_id = get_queried_object_id();

        if ($product_id < 1) {
            return;
        }

        $product = wc_get_product($product_id);

        if (!$product instanceof WC_Product || !$product->is_type('variable')) {
            return;
        }

        if (!self::is_enabled_for_product($product_id)) {
            return;
        }

        $settings = self::get_product_settings($product_id);
        $display_unit = self::get_settings_display_unit($settings);
        $display_unit_name = self::get_display_unit_name($display_unit);

        $style_version = file_exists(WVPC_PLUGIN_DIR . 'assets/frontend.css')
            ? (string) filemtime(WVPC_PLUGIN_DIR . 'assets/frontend.css')
            : WVPC_VERSION;
        $script_version = file_exists(WVPC_PLUGIN_DIR . 'assets/frontend.js')
            ? (string) filemtime(WVPC_PLUGIN_DIR . 'assets/frontend.js')
            : WVPC_VERSION;

        wp_enqueue_style(
            'wvpc-frontend',
            WVPC_PLUGIN_URL . 'assets/frontend.css',
            array(),
            $style_version
        );

        wp_enqueue_script(
            'wvpc-frontend',
            WVPC_PLUGIN_URL . 'assets/frontend.js',
            array('jquery', 'wc-add-to-cart-variation'),
            $script_version,
            true
        );

        wp_localize_script(
            'wvpc-frontend',
            'wvpcFrontend',
            array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce'   => wp_create_nonce('wvpc_calculate_price'),
                'i18n'    => array(
                    'baseLabel'            => __('Precio total de la cortina', 'woo-variable-pricing-csv'),
                    'placeholder'          => sprintf(__('Introduce ancho y alto en %s para calcular el precio.', 'woo-variable-pricing-csv'), $display_unit_name),
                    'chooseVariation'      => __('Elige una variación para calcular el precio.', 'woo-variable-pricing-csv'),
                    'missingMeasurements'  => sprintf(__('Introduce ancho y alto válidos en %s.', 'woo-variable-pricing-csv'), $display_unit_name),
                    'loading'              => __('Calculando precio...', 'woo-variable-pricing-csv'),
                    'liveUpdate'           => sprintf(__('El precio se actualiza en directo al cambiar las medidas en %s.', 'woo-variable-pricing-csv'), $display_unit_name),
                    'baseProductPrice'     => __('Precio base del producto', 'woo-variable-pricing-csv'),
                    'priceButtonPending'   => __('Completa medidas y variación para ver el precio', 'woo-variable-pricing-csv'),
                    'priceButtonPrefix'    => __('Precio total', 'woo-variable-pricing-csv'),
                    'pricePanelPending'    => __('Completa medidas y variación para ver el precio.', 'woo-variable-pricing-csv'),
                    'pricePanelHint'       => __('El precio calculado aparecerá aquí encima de la cantidad y del botón Añadir al carrito.', 'woo-variable-pricing-csv'),
                    'inlinePriceLabel'     => __('Precio', 'woo-variable-pricing-csv'),
                    'inlinePriceHint'      => sprintf(__('Selecciona variación y medidas en %s.', 'woo-variable-pricing-csv'), $display_unit_name),
                ),
            )
        );
    }

    /**
     * Render measurement inputs on the product page.
     *
     * @return void
     */
    public static function render_measure_fields() {
        global $product;

        if (!$product instanceof WC_Product || !$product->is_type('variable')) {
            return;
        }

        if (!self::is_enabled_for_product($product->get_id())) {
            return;
        }

        $settings            = self::get_product_settings($product->get_id());
        $display_unit        = self::get_settings_display_unit($settings);
        $display_unit_suffix = self::get_display_unit_suffix($display_unit);
        $display_unit_name   = self::get_display_unit_name($display_unit);
        $width_field_key     = 'wvpc_width_' . $display_unit;
        $height_field_key    = 'wvpc_height_' . $display_unit;
        $width               = self::get_display_measurement_value('width', $display_unit);
        $height              = self::get_display_measurement_value('height', $display_unit);

        echo '<div class="wvpc-measurements" data-product-id="' . esc_attr((string) $product->get_id()) . '">';
        echo '<div class="wvpc-measurements__grid">';
        echo '<p class="form-row form-row-first">';
        echo '<label for="' . esc_attr($width_field_key) . '">' . esc_html(sprintf(__('Ancho (%s)', 'woo-variable-pricing-csv'), $display_unit_suffix)) . '</label>';
        echo '<input type="number" class="input-text" name="' . esc_attr($width_field_key) . '" id="' . esc_attr($width_field_key) . '" min="' . esc_attr(self::format_mm_for_display_input($settings['min_width_mm'], $display_unit)) . '" max="' . esc_attr(self::format_mm_for_display_input($settings['max_width_mm'], $display_unit)) . '" step="' . esc_attr(self::format_mm_for_display_input($settings['width_step_mm'], $display_unit)) . '" value="' . esc_attr((string) $width) . '" inputmode="decimal" />';
        echo '<small class="wvpc-measurements__limits">' . esc_html(
            sprintf(
                /* translators: 1: minimum width, 2: maximum width, 3: measurement unit */
                __('Mín. %1$s %3$s · Máx. %2$s %3$s', 'woo-variable-pricing-csv'),
                self::format_mm_for_display_text($settings['min_width_mm'], $display_unit),
                self::format_mm_for_display_text($settings['max_width_mm'], $display_unit),
                $display_unit_suffix
            )
        ) . '</small>';
        echo '</p>';
        echo '<p class="form-row form-row-last">';
        echo '<label for="' . esc_attr($height_field_key) . '">' . esc_html(sprintf(__('Alto (%s)', 'woo-variable-pricing-csv'), $display_unit_suffix)) . '</label>';
        echo '<input type="number" class="input-text" name="' . esc_attr($height_field_key) . '" id="' . esc_attr($height_field_key) . '" min="' . esc_attr(self::format_mm_for_display_input($settings['min_height_mm'], $display_unit)) . '" max="' . esc_attr(self::format_mm_for_display_input($settings['max_height_mm'], $display_unit)) . '" step="' . esc_attr(self::format_mm_for_display_input($settings['height_step_mm'], $display_unit)) . '" value="' . esc_attr((string) $height) . '" inputmode="decimal" />';
        echo '<small class="wvpc-measurements__limits">' . esc_html(
            sprintf(
                /* translators: 1: minimum height, 2: maximum height, 3: measurement unit */
                __('Mín. %1$s %3$s · Máx. %2$s %3$s', 'woo-variable-pricing-csv'),
                self::format_mm_for_display_text($settings['min_height_mm'], $display_unit),
                self::format_mm_for_display_text($settings['max_height_mm'], $display_unit),
                $display_unit_suffix
            )
        ) . '</small>';
        echo '</p>';
        echo '</div>';
        echo '<input type="hidden" name="wvpc_calculated_price" value="" />';
        $measurements_note = sprintf(
            /* translators: 1: min width, 2: max width, 3: min height, 4: max height, 5: unit symbol, 6: unit name */
            __('Rango permitido: ancho %1$s-%2$s %5$s, alto %3$s-%4$s %5$s. Introduce las medidas en %6$s. El precio final aparecerá junto al botón Añadir al carrito.', 'woo-variable-pricing-csv'),
            self::format_mm_for_display_text($settings['min_width_mm'], $display_unit),
            self::format_mm_for_display_text($settings['max_width_mm'], $display_unit),
            self::format_mm_for_display_text($settings['min_height_mm'], $display_unit),
            self::format_mm_for_display_text($settings['max_height_mm'], $display_unit),
            $display_unit_suffix,
            $display_unit_name
        );
        echo '<p class="wvpc-measurements__note" data-default-note="' . esc_attr($measurements_note) . '" aria-live="polite">';
        echo esc_html($measurements_note);
        echo '</p>';
        echo '</div>';
    }

    /**
     * Render a compact inline price next to quantity and add to cart.
     *
     * @return void
     */
    public static function render_inline_price_panel() {
        global $product;

        if (!$product instanceof WC_Product || !$product->is_type('variable')) {
            return;
        }

        if (!self::is_enabled_for_product($product->get_id())) {
            return;
        }

        $price_html = $product->get_price_html();

        if ('' === $price_html) {
            $price_html = '--';
        }

        echo '<div class="wvpc-inline-price" aria-live="polite">';
        echo '<span class="wvpc-inline-price__label">' . esc_html__('Precio', 'woo-variable-pricing-csv') . '</span>';
        echo '<strong class="wvpc-inline-price__value">' . wp_kses_post($price_html) . '</strong>';
        echo '</div>';
    }

    /**
     * AJAX endpoint to preview the calculated price.
     *
     * @return void
     */
    public static function ajax_calculate_price() {
        check_ajax_referer('wvpc_calculate_price', 'nonce');

        $product_id   = isset($_POST['product_id']) ? absint(wp_unslash($_POST['product_id'])) : 0;
        $variation_id = isset($_POST['variation_id']) ? absint(wp_unslash($_POST['variation_id'])) : 0;
        $width_mm     = self::get_request_measurement('width');
        $height_mm    = self::get_request_measurement('height');
        $attributes   = isset($_POST['attributes']) && is_array($_POST['attributes']) ? self::sanitize_variation_attributes(wp_unslash($_POST['attributes'])) : array();

        $result = self::calculate_price($product_id, $variation_id, $width_mm, $height_mm, $attributes, true);

        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()), 400);
        }

        wp_send_json_success(
            array(
                'price'      => $result['price'],
                'base_price' => $result['base_price'],
                'surcharge_total'  => $result['surcharge_total'],
                'surcharge_labels' => $result['surcharge_labels'],
                'price_html' => $result['price_html'],
                'price_text' => wp_strip_all_tags($result['price_html']),
                'message'    => $result['message'],
                'variation_id' => $result['variation_id'],
                'width_mm'   => $result['width_mm'],
                'height_mm'  => $result['height_mm'],
                'display_unit' => $result['display_unit'],
                'width_cm'   => self::format_mm_as_cm_text($result['width_mm']),
                'height_cm'  => self::format_mm_as_cm_text($result['height_mm']),
                'width_display' => self::format_mm_for_display_text($result['width_mm'], $result['display_unit']),
                'height_display' => self::format_mm_for_display_text($result['height_mm'], $result['display_unit']),
            )
        );
    }

    /**
     * Validate the add to cart request.
     *
     * @param bool       $passed         Current validation state.
     * @param int        $product_id     Product ID.
     * @param int        $quantity       Requested quantity.
     * @param int        $variation_id   Variation ID.
     * @param array      $variations     Posted variation attributes.
     * @param array|null $cart_item_data Existing cart item data.
     * @return bool
     */
    public static function validate_add_to_cart($passed, $product_id, $quantity, $variation_id = 0, $variations = array(), $cart_item_data = null) {
        unset($quantity, $cart_item_data);

        if (!self::is_enabled_for_product($product_id)) {
            return $passed;
        }

        $width_mm   = self::get_posted_measurement('width');
        $height_mm  = self::get_posted_measurement('height');
        $attributes = !empty($variations) ? self::sanitize_variation_attributes($variations) : self::get_posted_variation_attributes();

        $result = self::calculate_price($product_id, $variation_id, $width_mm, $height_mm, $attributes);

        if (is_wp_error($result)) {
            wc_add_notice($result->get_error_message(), 'error');
            return false;
        }

        return $passed;
    }

    /**
     * Add measurement data to the cart item.
     *
     * @param array $cart_item_data Existing data.
     * @param int   $product_id     Product ID.
     * @param int   $variation_id   Variation ID.
     * @return array
     */
    public static function add_cart_item_data($cart_item_data, $product_id, $variation_id) {
        if (!self::is_enabled_for_product($product_id)) {
            return $cart_item_data;
        }

        $width_mm   = self::get_posted_measurement('width');
        $height_mm  = self::get_posted_measurement('height');
        $attributes = self::get_posted_variation_attributes();
        $result     = self::calculate_price($product_id, $variation_id, $width_mm, $height_mm, $attributes);

        if (is_wp_error($result)) {
            return $cart_item_data;
        }

        $cart_item_data['wvpc_measurement_data'] = array(
            'width_mm'   => $result['width_mm'],
            'height_mm'  => $result['height_mm'],
            'display_unit' => $result['display_unit'],
            'price'      => $result['price'],
            'rule_label' => $result['rule_label'],
            'surcharge_total'  => $result['surcharge_total'],
            'surcharge_labels' => $result['surcharge_labels'],
        );

        $cart_item_data['wvpc_configuration_key'] = md5($result['variation_id'] . '|' . $result['width_mm'] . '|' . $result['height_mm'] . '|' . $result['price'] . '|' . implode(',', $result['surcharge_labels']));

        return $cart_item_data;
    }

    /**
     * Show measurement data in the cart and checkout.
     *
     * @param array $item_data Existing displayed data.
     * @param array $cart_item Cart item.
     * @return array
     */
    public static function get_cart_item_display_data($item_data, $cart_item) {
        if (empty($cart_item['wvpc_measurement_data']) || !is_array($cart_item['wvpc_measurement_data'])) {
            return $item_data;
        }

        $measurement_data = $cart_item['wvpc_measurement_data'];
        $display_unit = !empty($measurement_data['display_unit'])
            ? self::sanitize_display_unit($measurement_data['display_unit'])
            : self::get_cart_item_display_unit($cart_item);

        $item_data[] = array(
            'key'   => __('Ancho', 'woo-variable-pricing-csv'),
            'value' => self::format_measurement_with_unit($measurement_data['width_mm'], $display_unit),
        );
        $item_data[] = array(
            'key'   => __('Alto', 'woo-variable-pricing-csv'),
            'value' => self::format_measurement_with_unit($measurement_data['height_mm'], $display_unit),
        );

        if (!empty($measurement_data['rule_label'])) {
            $item_data[] = array(
                'key'   => __('Tarifa aplicada', 'woo-variable-pricing-csv'),
                'value' => (string) $measurement_data['rule_label'],
            );
        }

        if (!empty($measurement_data['surcharge_labels'])) {
            $item_data[] = array(
                'key'   => __('Ajustes por atributo', 'woo-variable-pricing-csv'),
                'value' => implode(', ', array_map('strval', (array) $measurement_data['surcharge_labels'])),
            );
        }

        return $item_data;
    }

    /**
     * Apply custom calculated prices to cart items.
     *
     * @param \WC_Cart $cart WooCommerce cart.
     * @return void
     */
    public static function apply_cart_item_prices($cart) {
        if (!($cart instanceof WC_Cart)) {
            return;
        }

        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }

        foreach ($cart->get_cart() as $cart_item) {
            if (
                empty($cart_item['wvpc_measurement_data']) ||
                !is_array($cart_item['wvpc_measurement_data']) ||
                !array_key_exists('price', $cart_item['wvpc_measurement_data'])
            ) {
                continue;
            }

            $cart_item['data']->set_price((float) $cart_item['wvpc_measurement_data']['price']);
        }
    }

    /**
     * Persist measurement data on the order line item.
     *
     * @param \WC_Order_Item_Product $item          Order item.
     * @param string                 $cart_item_key Cart item key.
     * @param array                  $values        Cart item values.
     * @param \WC_Order              $order         Order instance.
     * @return void
     */
    public static function add_order_item_meta($item, $cart_item_key, $values, $order) {
        unset($cart_item_key, $order);

        if (empty($values['wvpc_measurement_data']) || !is_array($values['wvpc_measurement_data'])) {
            return;
        }

        $measurement_data = $values['wvpc_measurement_data'];

        $item->add_meta_data(self::ORDER_META_DATA,   wp_json_encode($measurement_data), true);
        $item->add_meta_data(self::ORDER_META_WIDTH,  (int) $measurement_data['width_mm'], true);
        $item->add_meta_data(self::ORDER_META_HEIGHT, (int) $measurement_data['height_mm'], true);

        if (!empty($measurement_data['rule_label'])) {
            $item->add_meta_data(self::ORDER_META_RATE, (string) $measurement_data['rule_label'], true);
        }

        if (!empty($measurement_data['surcharge_labels'])) {
            $item->add_meta_data(self::ORDER_META_SURCHARGES, implode(', ', array_map('strval', (array) $measurement_data['surcharge_labels'])), true);
        }
    }

    /**
     * Calculate the final price for the given variation and measurements.
     *
     * @param int $product_id   Product ID.
     * @param int          $variation_id       Variation ID.
     * @param string|int   $width_mm           Width entered by the customer in centimeters.
     * @param string|int   $height_mm          Height entered by the customer in centimeters.
     * @param array        $selected_attributes Selected variation attributes.
     * @param bool         $allow_generic_without_variation Allow previewing generic CSV rules before a variation ID is fully resolved.
     * @return array|\WP_Error
     */
    public static function calculate_price($product_id, $variation_id, $width_mm, $height_mm, $selected_attributes = array(), $allow_generic_without_variation = false) {
        $product_id = self::normalize_product_id($product_id);
        $product    = wc_get_product($product_id);

        if (!$product || !$product->is_type('variable')) {
            return new WP_Error('wvpc_invalid_product', __('El producto configurado no es un producto variable válido.', 'woo-variable-pricing-csv'));
        }

        if (!self::is_enabled_for_product($product_id)) {
            return new WP_Error('wvpc_not_enabled', __('El cálculo por medidas no está activo para este producto.', 'woo-variable-pricing-csv'));
        }

        $settings     = self::get_product_settings($product_id);
        $display_unit = self::get_settings_display_unit($settings);
        $measurements = self::normalize_customer_measurements($width_mm, $height_mm, $settings);

        if (is_wp_error($measurements)) {
            return $measurements;
        }

        $width_mm  = $measurements['width_mm'];
        $height_mm = $measurements['height_mm'];
        $valid     = self::validate_measurements($width_mm, $height_mm, $settings);

        if (is_wp_error($valid)) {
            return $valid;
        }

        $rules = self::get_rules($product_id);

        if (empty($rules)) {
            return new WP_Error('wvpc_missing_rules', __('Este producto todavía no tiene reglas de precio cargadas por CSV.', 'woo-variable-pricing-csv'));
        }

        $resolved_variation_id = self::resolve_selected_variation_id($product, $variation_id, $selected_attributes);
        $matching_variation_id = $resolved_variation_id;
        $variation             = false;

        if ($resolved_variation_id > 0) {
            $variation = wc_get_product($resolved_variation_id);

            if (!$variation || !($variation instanceof WC_Product_Variation) || (int) $variation->get_parent_id() !== $product_id) {
                return new WP_Error('wvpc_invalid_variation', __('La variación seleccionada no pertenece a este producto.', 'woo-variable-pricing-csv'));
            }
        } elseif ($allow_generic_without_variation && self::has_generic_rule($rules)) {
            $matching_variation_id = 0;
        } else {
            return new WP_Error('wvpc_missing_variation', __('Selecciona una variación antes de calcular el precio.', 'woo-variable-pricing-csv'));
        }

        $rule = self::find_matching_rule($rules, $matching_variation_id, $width_mm, $height_mm);

        if (is_wp_error($rule)) {
            return $rule;
        }

        $price = self::calculate_price_from_rule($rule, $width_mm, $height_mm);

        if (is_wp_error($price)) {
            return $price;
        }

        $base_price          = $price;
        $manual_surcharge    = self::calculate_attribute_surcharge($product_id, $variation, $selected_attributes, $base_price);
        $markup_surcharge    = self::calculate_markup_by_attribute_surcharge($product_id, $variation, $selected_attributes, $base_price);
        $surcharge_total     = round((float) $manual_surcharge['total'] + (float) $markup_surcharge['total'], wc_get_price_decimals());
        $surcharge_labels    = array_merge(
            self::format_attribute_surcharge_match_labels($manual_surcharge['matches']),
            self::format_markup_by_attribute_match_labels($markup_surcharge['matches'])
        );
        $price               = round(max(0, $base_price + $surcharge_total), wc_get_price_decimals());
        $rule_label          = self::get_rule_label($rule, $display_unit);
        $message           = sprintf(
            /* translators: 1: width with unit, 2: height with unit, 3: rule label */
            __('Medida %1$s x %2$s. Tarifa aplicada: %3$s.', 'woo-variable-pricing-csv'),
            self::format_measurement_with_unit($width_mm, $display_unit),
            self::format_measurement_with_unit($height_mm, $display_unit),
            $rule_label
        );

        if (!empty($surcharge_labels)) {
            $message .= ' ' . sprintf(
                /* translators: %s: applied attribute surcharges */
                __('Ajustes por atributo: %s.', 'woo-variable-pricing-csv'),
                implode(', ', $surcharge_labels)
            );
        }

        return array(
            'price'      => $price,
            'base_price' => $base_price,
            'surcharge_total'  => $surcharge_total,
            'surcharge_labels' => $surcharge_labels,
            'price_html' => wc_price($price),
            'message'    => $message,
            'rule'       => $rule,
            'rule_label' => $rule_label,
            'variation_id' => (int) $resolved_variation_id,
            'display_unit' => $display_unit,
            'width_mm'   => (int) $width_mm,
            'height_mm'  => (int) $height_mm,
        );
    }

    /**
     * Parse a CSV file into normalized pricing rules.
     *
     * @param \WC_Product $product  Variable product.
     * @param string      $file     Temporary CSV path.
     * @param string      $filename Original filename.
     * @return array|\WP_Error
     */
    public static function parse_csv_rules($product, $file, $filename = '') {
        unset($filename);

        $handle = fopen($file, 'r');

        if (!$handle) {
            return new WP_Error('wvpc_csv_open_failed', __('No se pudo abrir el archivo CSV.', 'woo-variable-pricing-csv'));
        }

        $first_line = fgets($handle);

        if (false === $first_line) {
            fclose($handle);
            return new WP_Error('wvpc_csv_empty', __('El CSV está vacío.', 'woo-variable-pricing-csv'));
        }

        $delimiter = self::detect_delimiter($first_line);
        rewind($handle);

        $raw_headers = self::read_csv_row($handle, $delimiter);

        if (empty($raw_headers)) {
            fclose($handle);
            return new WP_Error('wvpc_csv_headers', __('No se pudieron leer los encabezados del CSV.', 'woo-variable-pricing-csv'));
        }

        $headers = array();

        foreach ($raw_headers as $header) {
            $headers[] = self::canonicalize_header($header);
        }

        if (!self::has_dimension_headers($headers)) {
            fclose($handle);
            return new WP_Error('wvpc_csv_dimensions', __('El CSV debe incluir columnas de rango o medida exacta para ancho y alto en centímetros o milímetros.', 'woo-variable-pricing-csv'));
        }

        if (!self::has_pricing_headers($headers)) {
            fclose($handle);
            return new WP_Error('wvpc_csv_prices', __('El CSV debe incluir price o price_per_m2 para al menos una regla.', 'woo-variable-pricing-csv'));
        }

        $results = array(
            'processed'      => 0,
            'errors'         => 0,
            'error_messages' => array(),
            'rules'          => array(),
        );
        $settings     = self::get_product_settings($product->get_id());
        $display_unit = self::get_settings_display_unit($settings);
        $csv_unit     = self::get_settings_csv_unit($settings);

        $line_number = 1;

        while (($values = self::read_csv_row($handle, $delimiter)) !== false) {
            ++$line_number;

            if (self::is_blank_row($values)) {
                continue;
            }

            ++$results['processed'];

            $values = array_pad($values, count($headers), '');
            $values = array_slice($values, 0, count($headers));
            $row    = array_combine($headers, array_map(array(__CLASS__, 'clean_cell'), $values));

            if (!is_array($row)) {
                ++$results['errors'];
                $results['error_messages'][] = sprintf(__('Línea %d: no se pudo leer la fila.', 'woo-variable-pricing-csv'), $line_number);
                continue;
            }

            $legacy_dimension_unit = self::infer_legacy_exact_dimension_unit($row, $csv_unit);
            $rule                  = self::build_rule_from_row($product, $row, $legacy_dimension_unit, $display_unit, $csv_unit);

            if (is_wp_error($rule)) {
                ++$results['errors'];
                $results['error_messages'][] = sprintf(__('Línea %1$d: %2$s', 'woo-variable-pricing-csv'), $line_number, $rule->get_error_message());
                continue;
            }

            $results['rules'][] = $rule;
        }

        fclose($handle);

        if (empty($results['rules'])) {
            return new WP_Error('wvpc_csv_no_rules', __('No se ha podido guardar ninguna regla válida desde el CSV.', 'woo-variable-pricing-csv'));
        }

        usort(
            $results['rules'],
            function ($left, $right) {
                $compare = $left['variation_id'] <=> $right['variation_id'];

                if (0 !== $compare) {
                    return $compare;
                }

                $compare = $left['min_width_mm'] <=> $right['min_width_mm'];

                if (0 !== $compare) {
                    return $compare;
                }

                $compare = $left['min_height_mm'] <=> $right['min_height_mm'];

                if (0 !== $compare) {
                    return $compare;
                }

                return $left['max_width_mm'] <=> $right['max_width_mm'];
            }
        );

        return $results;
    }

    /**
     * Build a normalized rule from a CSV row.
     *
     * @param \WC_Product $product               Variable product.
     * @param array       $row                   CSV row.
     * @param string      $legacy_dimension_unit Inferred unit for legacy width/height columns.
     * @param string      $display_unit          Product display unit.
     * @param string      $csv_unit              Configured unit for legacy CSV columns.
     * @return array|\WP_Error
     */
    private static function build_rule_from_row($product, $row, $legacy_dimension_unit = 'auto', $display_unit = 'cm', $csv_unit = 'mm') {
        $variation_id = self::resolve_variation_id($product, $row);

        if (is_wp_error($variation_id)) {
            return $variation_id;
        }

        $bounds = self::extract_dimension_bounds($row, $legacy_dimension_unit, $csv_unit);

        if (is_wp_error($bounds)) {
            return $bounds;
        }

        $fixed_price = self::parse_nullable_price_decimal(
            self::first_non_empty_value($row, array('price', 'fixed_price')),
            __('precio fijo', 'woo-variable-pricing-csv')
        );
        $price_per_m2 = self::parse_nullable_price_decimal(
            self::first_non_empty_value($row, array('price_per_m2')),
            __('precio por m2', 'woo-variable-pricing-csv')
        );
        $base_price = self::parse_optional_price_decimal(
            self::first_non_empty_value($row, array('base_price')),
            __('precio base', 'woo-variable-pricing-csv')
        );
        $min_price = self::parse_optional_price_decimal(
            self::first_non_empty_value($row, array('min_price')),
            __('precio mínimo', 'woo-variable-pricing-csv')
        );

        if (is_wp_error($fixed_price)) {
            return $fixed_price;
        }

        if (is_wp_error($price_per_m2)) {
            return $price_per_m2;
        }

        if (is_wp_error($base_price)) {
            return $base_price;
        }

        if (is_wp_error($min_price)) {
            return $min_price;
        }

        if (null === $fixed_price && null === $price_per_m2) {
            return new WP_Error('wvpc_rule_missing_price', __('Cada regla debe indicar price o price_per_m2.', 'woo-variable-pricing-csv'));
        }

        return array(
            'variation_id'  => (int) $variation_id,
            'min_width_mm'  => (int) $bounds['min_width_mm'],
            'max_width_mm'  => (int) $bounds['max_width_mm'],
            'min_height_mm' => (int) $bounds['min_height_mm'],
            'max_height_mm' => (int) $bounds['max_height_mm'],
            'lookup_mode'   => isset($bounds['lookup_mode']) ? (string) $bounds['lookup_mode'] : 'range',
            'fixed_price'   => null !== $fixed_price ? (float) $fixed_price : null,
            'price_per_m2'  => null !== $price_per_m2 ? (float) $price_per_m2 : null,
            'base_price'    => (float) $base_price,
            'min_price'     => (float) $min_price,
            'label'         => self::build_rule_label($row, $bounds, $display_unit),
            'label_custom'  => !empty($row['label']),
        );
    }

    /**
     * Validate measurements against product settings.
     *
     * @param int   $width_mm  Width in millimeters.
     * @param int   $height_mm Height in millimeters.
     * @param array $settings  Product settings.
     * @return true|\WP_Error
     */
    private static function validate_measurements($width_mm, $height_mm, $settings) {
        $display_unit = self::get_settings_display_unit($settings);
        $display_unit_suffix = self::get_display_unit_suffix($display_unit);
        $display_unit_name = self::get_display_unit_name($display_unit);

        if ($width_mm < 1 || $height_mm < 1) {
            return new WP_Error('wvpc_missing_measurements', sprintf(__('Introduce ancho y alto válidos en %s.', 'woo-variable-pricing-csv'), $display_unit_name));
        }

        if ($width_mm < $settings['min_width_mm'] || $width_mm > $settings['max_width_mm']) {
            return new WP_Error(
                'wvpc_width_out_of_range',
                sprintf(
                    /* translators: 1: minimum width, 2: maximum width, 3: unit symbol */
                    __('El ancho debe estar entre %1$s y %2$s %3$s.', 'woo-variable-pricing-csv'),
                    self::format_mm_for_display_text($settings['min_width_mm'], $display_unit),
                    self::format_mm_for_display_text($settings['max_width_mm'], $display_unit),
                    $display_unit_suffix
                )
            );
        }

        if ($height_mm < $settings['min_height_mm'] || $height_mm > $settings['max_height_mm']) {
            return new WP_Error(
                'wvpc_height_out_of_range',
                sprintf(
                    /* translators: 1: minimum height, 2: maximum height, 3: unit symbol */
                    __('El alto debe estar entre %1$s y %2$s %3$s.', 'woo-variable-pricing-csv'),
                    self::format_mm_for_display_text($settings['min_height_mm'], $display_unit),
                    self::format_mm_for_display_text($settings['max_height_mm'], $display_unit),
                    $display_unit_suffix
                )
            );
        }

        if ($settings['width_step_mm'] > 1 && 0 !== ($width_mm % $settings['width_step_mm'])) {
            return new WP_Error(
                'wvpc_width_step',
                sprintf(
                    /* translators: 1: width step, 2: unit symbol */
                    __('El ancho debe avanzar en saltos de %1$s %2$s.', 'woo-variable-pricing-csv'),
                    self::format_mm_for_display_text($settings['width_step_mm'], $display_unit),
                    $display_unit_suffix
                )
            );
        }

        if ($settings['height_step_mm'] > 1 && 0 !== ($height_mm % $settings['height_step_mm'])) {
            return new WP_Error(
                'wvpc_height_step',
                sprintf(
                    /* translators: 1: height step, 2: unit symbol */
                    __('El alto debe avanzar en saltos de %1$s %2$s.', 'woo-variable-pricing-csv'),
                    self::format_mm_for_display_text($settings['height_step_mm'], $display_unit),
                    $display_unit_suffix
                )
            );
        }

        return true;
    }

    /**
     * Normalize customer measurements from centimeters to millimeters.
     *
     * @param string|int $width_value  Customer width.
     * @param string|int $height_value Customer height.
     * @param array      $settings     Product settings.
     * @return array|\WP_Error
     */
    private static function normalize_customer_measurements($width_value, $height_value, $settings) {
        $width_mm = self::normalize_customer_measurement(
            $width_value,
            __('ancho', 'woo-variable-pricing-csv')
        );

        if (is_wp_error($width_mm)) {
            return $width_mm;
        }

        $height_mm = self::normalize_customer_measurement(
            $height_value,
            __('alto', 'woo-variable-pricing-csv')
        );

        if (is_wp_error($height_mm)) {
            return $height_mm;
        }

        return array(
            'width_mm'  => (int) $width_mm,
            'height_mm' => (int) $height_mm,
        );
    }

    /**
     * Normalize a single customer measurement from centimeters to millimeters.
     *
     * @param string|int $value          Raw customer value.
     * @param string     $label          Measurement label.
     * @return int|\WP_Error
     */
    private static function normalize_customer_measurement($value, $label) {
        $number = self::parse_decimal($value, $label);

        if (is_wp_error($number)) {
            return $number;
        }

        $normalized = ((float) $number) * 10;

        if (abs($normalized - round($normalized)) > 0.00001) {
            return new WP_Error(
                'wvpc_measurement_not_integer',
                sprintf(__('El campo %s debe corresponder con una medida válida en la unidad seleccionada.', 'woo-variable-pricing-csv'), $label)
            );
        }

        $normalized = (int) round($normalized);

        if ($normalized < 1) {
            return new WP_Error('wvpc_measurement_invalid', sprintf(__('El campo %s debe ser mayor que cero.', 'woo-variable-pricing-csv'), $label));
        }

        return $normalized;
    }

    /**
     * Find the best matching rule for a variation and dimensions.
     *
     * @param array $rules        Stored rules.
     * @param int   $variation_id Variation ID.
     * @param int   $width_mm     Width in millimeters.
     * @param int   $height_mm    Height in millimeters.
     * @return array|\WP_Error
     */
    private static function find_matching_rule($rules, $variation_id, $width_mm, $height_mm) {
        $matches = array();

        foreach ($rules as $rule) {
            $rule_variation_id = isset($rule['variation_id']) ? (int) $rule['variation_id'] : 0;

            if (0 !== $rule_variation_id && $rule_variation_id !== (int) $variation_id) {
                continue;
            }

            $lookup_mode = isset($rule['lookup_mode']) ? (string) $rule['lookup_mode'] : 'range';

            if ('matrix' === $lookup_mode) {
                $enforce_min_width  = (int) $rule['min_width_mm'] < (int) $rule['max_width_mm'];
                $enforce_min_height = (int) $rule['min_height_mm'] < (int) $rule['max_height_mm'];

                if (
                    ($enforce_min_width && $width_mm < (int) $rule['min_width_mm']) ||
                    $width_mm > (int) $rule['max_width_mm'] ||
                    ($enforce_min_height && $height_mm < (int) $rule['min_height_mm']) ||
                    $height_mm > (int) $rule['max_height_mm']
                ) {
                    continue;
                }
            } else {
                if ($width_mm < (int) $rule['min_width_mm'] || $width_mm > (int) $rule['max_width_mm']) {
                    continue;
                }

                if ($height_mm < (int) $rule['min_height_mm'] || $height_mm > (int) $rule['max_height_mm']) {
                    continue;
                }
            }

            $matches[] = $rule;
        }

        if (empty($matches)) {
            return new WP_Error('wvpc_rule_not_found', __('No existe una tarifa para esa combinación de variación y medidas.', 'woo-variable-pricing-csv'));
        }

        $specific_matches = array_values(
            array_filter(
                $matches,
                function ($rule) use ($variation_id) {
                    return isset($rule['variation_id']) && (int) $rule['variation_id'] === (int) $variation_id;
                }
            )
        );

        if (!empty($specific_matches)) {
            $matches = $specific_matches;
        }

        usort($matches, array(__CLASS__, 'compare_matching_rules'));

        return $matches[0];
    }

    /**
     * Determine whether the imported rules include at least one generic row.
     *
     * Generic rows use variation_id = 0 and can be previewed before WooCommerce
     * resolves the selected variation in the frontend.
     *
     * @param array $rules Stored rules.
     * @return bool
     */
    private static function has_generic_rule($rules) {
        foreach ((array) $rules as $rule) {
            if (!is_array($rule)) {
                continue;
            }

            if (empty($rule['variation_id'])) {
                return true;
            }
        }

        return false;
    }

    /**
     * Calculate the final numeric price from a rule.
     *
     * @param array $rule      Matching rule.
     * @param int   $width_mm  Width in millimeters.
     * @param int   $height_mm Height in millimeters.
     * @return float|\WP_Error
     */
    private static function calculate_price_from_rule($rule, $width_mm, $height_mm) {
        if (null !== $rule['fixed_price']) {
            $price = (float) $rule['fixed_price'];
        } else {
            if (null === $rule['price_per_m2']) {
                return new WP_Error('wvpc_rule_without_formula', __('La regla encontrada no tiene un precio calculable.', 'woo-variable-pricing-csv'));
            }

            $area_m2 = ((float) $width_mm / 1000) * ((float) $height_mm / 1000);
            $price   = (float) $rule['base_price'] + ($area_m2 * (float) $rule['price_per_m2']);

            if ((float) $rule['min_price'] > 0 && $price < (float) $rule['min_price']) {
                $price = (float) $rule['min_price'];
            }
        }

        $price = round($price, wc_get_price_decimals());

        if ($price < 0) {
            return new WP_Error('wvpc_negative_price', __('La tarifa calculada genera un precio negativo.', 'woo-variable-pricing-csv'));
        }

        return $price;
    }

    /**
     * Normalize a product ID to its parent product when needed.
     *
     * @param int $product_id Product or variation ID.
     * @return int
     */
    private static function normalize_product_id($product_id) {
        $product_id = absint($product_id);
        $product    = wc_get_product($product_id);

        if ($product instanceof WC_Product_Variation) {
            return (int) $product->get_parent_id();
        }

        return $product_id;
    }

    /**
     * Resolve a variation from variation_id, sku or attributes.
     *
     * @param \WC_Product $product Variable product.
     * @param array       $row     CSV row.
     * @return int|\WP_Error
     */
    private static function resolve_variation_id($product, $row) {
        $variation_id = isset($row['variation_id']) ? absint($row['variation_id']) : 0;

        if ($variation_id > 0) {
            $variation = wc_get_product($variation_id);

            if (!$variation || !($variation instanceof WC_Product_Variation)) {
                return new WP_Error('wvpc_variation_id_invalid', __('El variation_id indicado no corresponde a una variación válida.', 'woo-variable-pricing-csv'));
            }

            if ((int) $variation->get_parent_id() !== (int) $product->get_id()) {
                return new WP_Error('wvpc_variation_id_parent', __('El variation_id indicado no pertenece al producto actual.', 'woo-variable-pricing-csv'));
            }

            return (int) $variation_id;
        }

        $sku = isset($row['sku']) ? trim((string) $row['sku']) : '';

        if ('' !== $sku) {
            $sku_product_id = wc_get_product_id_by_sku($sku);

            if (!$sku_product_id) {
                return new WP_Error('wvpc_sku_missing', __('El SKU indicado no existe en WooCommerce.', 'woo-variable-pricing-csv'));
            }

            $variation = wc_get_product($sku_product_id);

            if (!$variation || !($variation instanceof WC_Product_Variation)) {
                return new WP_Error('wvpc_sku_invalid', __('El SKU indicado no pertenece a una variación.', 'woo-variable-pricing-csv'));
            }

            if ((int) $variation->get_parent_id() !== (int) $product->get_id()) {
                return new WP_Error('wvpc_sku_parent', __('El SKU indicado no pertenece al producto actual.', 'woo-variable-pricing-csv'));
            }

            return (int) $variation->get_id();
        }

        $row_attributes = self::extract_row_attributes($row);

        if (empty($row_attributes)) {
            return 0;
        }

        $matches = array();

        foreach ($product->get_children() as $child_id) {
            $variation = wc_get_product($child_id);

            if (!$variation || !($variation instanceof WC_Product_Variation)) {
                continue;
            }

            if (self::row_matches_variation($variation->get_attributes(), $row_attributes)) {
                $matches[] = (int) $child_id;
            }
        }

        if (empty($matches)) {
            return new WP_Error('wvpc_row_match_missing', __('No se encontró una variación que coincida con los atributos de la fila.', 'woo-variable-pricing-csv'));
        }

        if (count($matches) > 1) {
            return new WP_Error('wvpc_row_match_ambiguous', __('La fila coincide con varias variaciones. Añade variation_id o sku para evitar ambigüedad.', 'woo-variable-pricing-csv'));
        }

        return $matches[0];
    }

    /**
     * Compare CSV attributes with variation attributes.
     *
     * @param array $variation_attributes Variation attributes.
     * @param array $row_attributes       CSV attributes.
     * @return bool
     */
    private static function row_matches_variation($variation_attributes, $row_attributes) {
        $lookup = array();

        foreach ($variation_attributes as $attribute_key => $attribute_value) {
            $normalized_key   = self::canonicalize_header($attribute_key);
            $normalized_value = self::normalize_attribute_value($attribute_value);
            $candidate_keys   = array($normalized_key);
            $stripped_key     = preg_replace('/^attribute_/', '', $normalized_key);

            $candidate_keys[] = $stripped_key;

            if (0 === strpos($stripped_key, 'pa_')) {
                $candidate_keys[] = substr($stripped_key, 3);
            }

            foreach (array_unique($candidate_keys) as $candidate_key) {
                $lookup[$candidate_key] = $normalized_value;
            }
        }

        foreach ($row_attributes as $row_key => $row_value) {
            $candidate_keys   = array($row_key);
            $normalized_value = self::normalize_attribute_value($row_value);

            if (0 === strpos($row_key, 'attribute_')) {
                $candidate_keys[] = preg_replace('/^attribute_/', '', $row_key);
            }

            if (0 === strpos($row_key, 'attribute_pa_')) {
                $candidate_keys[] = substr($row_key, 13);
            }

            if (0 === strpos($row_key, 'pa_')) {
                $candidate_keys[] = substr($row_key, 3);
            }

            $matched = false;

            foreach (array_unique($candidate_keys) as $candidate_key) {
                if (isset($lookup[$candidate_key]) && $lookup[$candidate_key] === $normalized_value) {
                    $matched = true;
                    break;
                }
            }

            if (!$matched) {
                return false;
            }
        }

        return true;
    }

    /**
     * Extract non-reserved columns as attributes.
     *
     * @param array $row CSV row.
     * @return array
     */
    private static function extract_row_attributes($row) {
        $attributes = array();
        $reserved   = self::get_reserved_columns();

        foreach ($row as $key => $value) {
            if ('' === trim((string) $value) || in_array($key, $reserved, true)) {
                continue;
            }

            $attributes[$key] = $value;
        }

        return $attributes;
    }

    /**
     * Extract width and height bounds from a row.
     *
     * @param array  $row                   CSV row.
     * @param string $legacy_dimension_unit Inferred unit for legacy width/height columns.
     * @param string $csv_unit              Configured unit for legacy CSV columns.
     * @return array|\WP_Error
     */
    private static function extract_dimension_bounds($row, $legacy_dimension_unit = 'auto', $csv_unit = 'mm') {
        $exact_width_mm  = self::first_non_empty_value($row, array('width_mm'));
        $exact_width_cm  = self::first_non_empty_value($row, array('width_cm'));
        $exact_height_mm = self::first_non_empty_value($row, array('height_mm'));
        $exact_height_cm = self::first_non_empty_value($row, array('height_cm'));
        $exact_width     = self::first_non_empty_value($row, array('width'));
        $exact_height    = self::first_non_empty_value($row, array('height'));
        $csv_unit        = self::sanitize_csv_unit($csv_unit);

        $has_exact_width  = null !== $exact_width_mm || null !== $exact_width_cm || null !== $exact_width;
        $has_exact_height = null !== $exact_height_mm || null !== $exact_height_cm || null !== $exact_height;

        if ($has_exact_width) {
            if (null !== $exact_width_mm) {
                $width = self::parse_positive_integer($exact_width_mm, __('ancho exacto', 'woo-variable-pricing-csv'));
            } elseif (null !== $exact_width_cm) {
                $width = self::parse_explicit_centimeters_or_legacy_millimeters_to_mm($exact_width_cm, __('ancho exacto', 'woo-variable-pricing-csv'), $csv_unit);
            } else {
                $width = self::parse_legacy_exact_dimension_to_mm($exact_width, __('ancho exacto', 'woo-variable-pricing-csv'), $legacy_dimension_unit, $csv_unit);
            }

            if (is_wp_error($width)) {
                return $width;
            }

            $min_width = $width;
            $max_width = $width;
        } else {
            $min_width_mm = self::first_non_empty_value($row, array('min_width_mm'));
            $max_width_mm = self::first_non_empty_value($row, array('max_width_mm'));
            $min_width_cm = self::first_non_empty_value($row, array('min_width_cm'));
            $max_width_cm = self::first_non_empty_value($row, array('max_width_cm'));

            $min_width = null !== $min_width_mm
                ? self::parse_positive_integer($min_width_mm, __('ancho mínimo', 'woo-variable-pricing-csv'))
                : self::parse_explicit_centimeters_or_legacy_millimeters_to_mm($min_width_cm, __('ancho mínimo', 'woo-variable-pricing-csv'), $csv_unit);
            $max_width = null !== $max_width_mm
                ? self::parse_positive_integer($max_width_mm, __('ancho máximo', 'woo-variable-pricing-csv'))
                : self::parse_explicit_centimeters_or_legacy_millimeters_to_mm($max_width_cm, __('ancho máximo', 'woo-variable-pricing-csv'), $csv_unit);

            if (is_wp_error($min_width)) {
                return $min_width;
            }

            if (is_wp_error($max_width)) {
                return $max_width;
            }
        }

        if ($has_exact_height) {
            if (null !== $exact_height_mm) {
                $height = self::parse_positive_integer($exact_height_mm, __('alto exacto', 'woo-variable-pricing-csv'));
            } elseif (null !== $exact_height_cm) {
                $height = self::parse_explicit_centimeters_or_legacy_millimeters_to_mm($exact_height_cm, __('alto exacto', 'woo-variable-pricing-csv'), $csv_unit);
            } else {
                $height = self::parse_legacy_exact_dimension_to_mm($exact_height, __('alto exacto', 'woo-variable-pricing-csv'), $legacy_dimension_unit, $csv_unit);
            }

            if (is_wp_error($height)) {
                return $height;
            }

            $min_height = $height;
            $max_height = $height;
        } else {
            $min_height_mm = self::first_non_empty_value($row, array('min_height_mm'));
            $max_height_mm = self::first_non_empty_value($row, array('max_height_mm'));
            $min_height_cm = self::first_non_empty_value($row, array('min_height_cm'));
            $max_height_cm = self::first_non_empty_value($row, array('max_height_cm'));

            $min_height = null !== $min_height_mm
                ? self::parse_positive_integer($min_height_mm, __('alto mínimo', 'woo-variable-pricing-csv'))
                : self::parse_explicit_centimeters_or_legacy_millimeters_to_mm($min_height_cm, __('alto mínimo', 'woo-variable-pricing-csv'), $csv_unit);
            $max_height = null !== $max_height_mm
                ? self::parse_positive_integer($max_height_mm, __('alto máximo', 'woo-variable-pricing-csv'))
                : self::parse_explicit_centimeters_or_legacy_millimeters_to_mm($max_height_cm, __('alto máximo', 'woo-variable-pricing-csv'), $csv_unit);

            if (is_wp_error($min_height)) {
                return $min_height;
            }

            if (is_wp_error($max_height)) {
                return $max_height;
            }
        }

        $lookup_mode = ($has_exact_width && $has_exact_height) ? 'matrix' : 'range';

        if ($max_width < $min_width) {
            return new WP_Error('wvpc_width_bounds', __('El ancho máximo no puede ser menor que el ancho mínimo.', 'woo-variable-pricing-csv'));
        }

        if ($max_height < $min_height) {
            return new WP_Error('wvpc_height_bounds', __('El alto máximo no puede ser menor que el alto mínimo.', 'woo-variable-pricing-csv'));
        }

        return array(
            'min_width_mm'  => $min_width,
            'max_width_mm'  => $max_width,
            'min_height_mm' => $min_height,
            'max_height_mm' => $max_height,
            'lookup_mode'   => $lookup_mode,
        );
    }

    /**
     * Build a human-readable rule label.
     *
     * @param array $row    CSV row.
     * @param array $bounds Rule bounds.
     * @return string
     */
    private static function build_rule_label($row, $bounds, $display_unit = 'cm') {
        if (!empty($row['label'])) {
            return (string) $row['label'];
        }

        return self::build_generated_rule_label($bounds, $display_unit);
    }

    /**
     * Return a label for a stored rule.
     *
     * @param array $rule Pricing rule.
     * @return string
     */
    private static function get_rule_label($rule, $display_unit = 'cm') {
        if (!empty($rule['label'])) {
            $stored_label = (string) $rule['label'];

            if (!empty($rule['label_custom'])) {
                return $stored_label;
            }

            $generated_cm = self::build_generated_rule_label($rule, 'cm');
            $generated_mm = self::build_generated_rule_label($rule, 'mm');

            if ($stored_label !== $generated_cm && $stored_label !== $generated_mm) {
                return $stored_label;
            }
        }

        return self::build_generated_rule_label($rule, $display_unit);
    }

    /**
     * Build the generated label for a rule or raw bounds array in the requested unit.
     *
     * @param array  $bounds_or_rule Rule bounds.
     * @param string $display_unit   Display unit.
     * @return string
     */
    private static function build_generated_rule_label($bounds_or_rule, $display_unit = 'cm') {
        if (isset($bounds_or_rule['lookup_mode']) && 'matrix' === $bounds_or_rule['lookup_mode']) {
            return sprintf(
                __('Hasta %1$s x %2$s %3$s', 'woo-variable-pricing-csv'),
                self::format_mm_for_display_text($bounds_or_rule['max_width_mm'], $display_unit),
                self::format_mm_for_display_text($bounds_or_rule['max_height_mm'], $display_unit),
                self::get_display_unit_suffix($display_unit)
            );
        }

        return sprintf(
            '%1$s-%2$s x %3$s-%4$s %5$s',
            self::format_mm_for_display_text($bounds_or_rule['min_width_mm'], $display_unit),
            self::format_mm_for_display_text($bounds_or_rule['max_width_mm'], $display_unit),
            self::format_mm_for_display_text($bounds_or_rule['min_height_mm'], $display_unit),
            self::format_mm_for_display_text($bounds_or_rule['max_height_mm'], $display_unit),
            self::get_display_unit_suffix($display_unit)
        );
    }

    /**
     * Read a CSV row with PHP-version-safe parameters for fgetcsv().
     *
     * @param resource $handle    Open file handle.
     * @param string   $delimiter CSV delimiter.
     * @return array|false
     */
    private static function read_csv_row($handle, $delimiter) {
        if (PHP_VERSION_ID >= 80300) {
            return fgetcsv($handle, null, $delimiter);
        }

        return fgetcsv($handle, 0, $delimiter);
    }

    /**
     * Parse one textarea line into an attribute surcharge rule.
     *
     * @param string $line Raw rule line.
     * @return array
     */
    private static function parse_attribute_surcharge_line($line) {
        $line = trim(self::clean_cell($line));

        if (preg_match('/^([^=:;|]+?)\s*=\s*([^:;|]+?)\s*[:|]\s*(.+)$/', $line, $matches)) {
            return self::normalize_attribute_surcharge_rule($matches[1], $matches[2], $matches[3]);
        }

        foreach (array(';', ',') as $delimiter) {
            $parts = str_getcsv($line, $delimiter);

            if (3 === count($parts)) {
                return self::normalize_attribute_surcharge_rule($parts[0], $parts[1], $parts[2]);
            }
        }

        return array();
    }

    /**
     * Normalize a surcharge rule.
     *
     * @param string $attribute Raw attribute key/name.
     * @param string $value     Raw attribute value.
     * @param string $amount    Raw surcharge amount.
     * @param string $mode      Raw surcharge mode.
     * @return array
     */
    private static function normalize_attribute_surcharge_rule($attribute, $value, $amount, $mode = '') {
        $attribute_label = self::clean_cell($attribute);
        $value_label     = self::clean_cell($value);
        $attribute_key   = self::normalize_attribute_key($attribute_label);
        $attribute_value = self::normalize_attribute_value($value_label);
        $amount_spec     = self::parse_attribute_surcharge_amount_spec($amount, $mode);

        if (is_wp_error($amount_spec) || '' === $attribute_key || '' === $attribute_value) {
            return array();
        }

        return array(
            'attribute'       => $attribute_key,
            'value'           => $attribute_value,
            'mode'            => $amount_spec['mode'],
            'amount'          => $amount_spec['amount'],
            'attribute_label' => $attribute_label,
            'value_label'     => $value_label,
            'label'           => sprintf('%1$s=%2$s', $attribute_label, $value_label),
        );
    }

    /**
     * Parse a surcharge amount specification.
     *
     * Supported formats:
     * - 25      → fixed surcharge
     * - *1.15   → multiplier over the calculated base price
     * - x1.15   → multiplier over the calculated base price
     *
     * @param string $amount Raw amount value.
     * @param string $mode   Optional explicit mode.
     * @return array|\WP_Error
     */
    private static function parse_attribute_surcharge_amount_spec($amount, $mode = '') {
        $raw_amount = self::clean_cell($amount);
        $mode       = self::sanitize_attribute_surcharge_mode($mode);

        if ('' === $raw_amount) {
            return new WP_Error('wvpc_surcharge_amount_empty', __('El recargo por atributo no puede estar vacío.', 'woo-variable-pricing-csv'));
        }

        if ('fixed' === $mode && preg_match('/^\s*(?:\*|x|X|×)\s*(.+)\s*$/u', $raw_amount, $matches)) {
            $mode       = 'multiplier';
            $raw_amount = $matches[1];
        } elseif (preg_match('/^\s*(?:\*|x|X|×)\s*(.+)\s*$/u', $raw_amount, $matches)) {
            $mode       = 'multiplier';
            $raw_amount = $matches[1];
        }

        if ('multiplier' === $mode) {
            $multiplier = self::parse_decimal($raw_amount, __('multiplicador por atributo', 'woo-variable-pricing-csv'));

            if (is_wp_error($multiplier) || (float) $multiplier <= 0) {
                return new WP_Error('wvpc_surcharge_multiplier_invalid', __('El multiplicador por atributo debe ser un número mayor que 0.', 'woo-variable-pricing-csv'));
            }

            return array(
                'mode'   => 'multiplier',
                'amount' => round((float) $multiplier, 6),
            );
        }

        $fixed_amount = self::parse_price_decimal($raw_amount, __('recargo por atributo', 'woo-variable-pricing-csv'));

        if (is_wp_error($fixed_amount) || (float) $fixed_amount <= 0) {
            return new WP_Error('wvpc_surcharge_amount_invalid', __('El recargo fijo por atributo debe ser un importe mayor que 0.', 'woo-variable-pricing-csv'));
        }

        return array(
            'mode'   => 'fixed',
            'amount' => round((float) $fixed_amount, wc_get_price_decimals()),
        );
    }

    /**
     * Sanitize the stored surcharge mode.
     *
     * @param string $mode Raw mode.
     * @return string
     */
    private static function sanitize_attribute_surcharge_mode($mode) {
        $normalized = strtolower(trim((string) $mode));

        return in_array($normalized, array('multiplier', 'multiply', 'factor', 'x'), true)
            ? 'multiplier'
            : 'fixed';
    }

    /**
     * Preserve every valid surcharge rule in the same order entered by the admin.
     *
     * Each textarea line is treated as an independent recargo. We do not collapse
     * repeated attribute/value pairs here, because stores may intentionally define:
     * - several fixed recargos for the same option
     * - one multiplier plus one or more fixed recargos
     * - repeated lines they want to keep exactly as entered
     *
     * @param array $rules Normalized rules.
     * @return array
     */
    private static function deduplicate_attribute_surcharge_rules($rules) {
        $normalized_rules = array();

        foreach ($rules as $rule) {
            if (empty($rule['attribute']) || empty($rule['value']) || !isset($rule['amount'])) {
                continue;
            }

            $rule['mode'] = self::sanitize_attribute_surcharge_mode(isset($rule['mode']) ? $rule['mode'] : 'fixed');
            $normalized_rules[] = $rule;
        }

        return $normalized_rules;
    }

    /**
     * Calculate surcharge total for attributes selected in the variation form.
     *
     * @param int                   $product_id          Parent product ID.
     * @param \WC_Product_Variation $variation           Selected variation.
     * @param array                 $selected_attributes Posted attributes.
     * @param float                 $base_price          CSV price before attribute recargos.
     * @return array
     */
    private static function calculate_attribute_surcharge($product_id, $variation, $selected_attributes, $base_price = 0.0) {
        $rules = self::get_attribute_surcharge_rules($product_id);

        if (empty($rules)) {
            return array(
                'total'   => 0.0,
                'matches' => array(),
            );
        }

        $lookup             = self::build_selected_attribute_lookup($variation, $selected_attributes);
        $fixed_matches      = array();
        $multiplier_matches = array();

        foreach ($rules as $rule) {
            $matched = false;

            foreach (self::get_attribute_key_variants($rule['attribute']) as $attribute_key) {
                if (
                    isset($lookup[$attribute_key]) &&
                    is_array($lookup[$attribute_key]) &&
                    in_array((string) $rule['value'], $lookup[$attribute_key], true)
                ) {
                    $matched = true;
                    break;
                }
            }

            if (!$matched) {
                continue;
            }

            $mode = self::sanitize_attribute_surcharge_mode(isset($rule['mode']) ? $rule['mode'] : 'fixed');

            if ('multiplier' === $mode) {
                $multiplier_matches[] = $rule;
            } else {
                $fixed_matches[] = $rule;
            }
        }

        $matches          = array();
        $multiplier_total = 0.0;
        $running_price    = (float) $base_price;

        foreach ($multiplier_matches as $rule) {
            $factor     = isset($rule['amount']) ? (float) $rule['amount'] : 1.0;
            $adjustment = ($running_price * $factor) - $running_price;
            $rule['applied_adjustment'] = round($adjustment, wc_get_price_decimals());
            $matches[] = $rule;
            $multiplier_total += $adjustment;
            $running_price += $adjustment;
        }

        $fixed_total = 0.0;

        foreach ($fixed_matches as $rule) {
            $adjustment = isset($rule['amount']) ? (float) $rule['amount'] : 0.0;
            $rule['applied_adjustment'] = round($adjustment, wc_get_price_decimals());
            $matches[] = $rule;
            $fixed_total += $adjustment;
        }

        return array(
            'total'   => round($multiplier_total + $fixed_total, wc_get_price_decimals()),
            'matches' => $matches,
        );
    }

    /**
     * Calculate markups configured in Markup by Attribute for WooCommerce.
     *
     * The external plugin stores raw markups in term meta as mt2mba_markup and,
     * after reapplying markups, stores calculated amounts on the parent product.
     * We prefer the applied product amount when present, then fall back to the
     * current term markup so dynamic CSV prices still work without extra steps.
     *
     * @param int                   $product_id          Parent product ID.
     * @param \WC_Product_Variation $variation           Selected variation.
     * @param array                 $selected_attributes Posted attributes.
     * @param float                 $base_price          CSV price before markups.
     * @return array
     */
    private static function calculate_markup_by_attribute_surcharge($product_id, $variation, $selected_attributes, $base_price) {
        if (!self::is_markup_by_attribute_active()) {
            return array(
                'total'   => 0.0,
                'matches' => array(),
            );
        }

        $terms = self::get_selected_global_attribute_terms($variation, $selected_attributes);

        if (empty($terms)) {
            return array(
                'total'   => 0.0,
                'matches' => array(),
            );
        }

        $matches = array();
        $total   = 0.0;

        foreach ($terms as $term_data) {
            $term_id = isset($term_data['term_id']) ? (int) $term_data['term_id'] : 0;

            if ($term_id < 1) {
                continue;
            }

            $amount = self::get_markup_by_attribute_applied_amount($product_id, $term_id);
            $source = 'applied';

            if (null === $amount) {
                $raw_markup = get_term_meta($term_id, 'mt2mba_markup', true);
                $amount     = self::calculate_markup_by_attribute_term_amount($raw_markup, $base_price);
                $source     = 'term';
            } else {
                $raw_markup = get_term_meta($term_id, 'mt2mba_markup', true);
            }

            if (null === $amount || 0.0 === (float) $amount) {
                continue;
            }

            $amount   = round((float) $amount, wc_get_price_decimals());
            $total   += $amount;
            $matches[] = array(
                'attribute_label' => isset($term_data['attribute_label']) ? (string) $term_data['attribute_label'] : '',
                'term_name'       => isset($term_data['term_name']) ? (string) $term_data['term_name'] : '',
                'term_slug'       => isset($term_data['term_slug']) ? (string) $term_data['term_slug'] : '',
                'term_id'         => $term_id,
                'amount'          => $amount,
                'raw_markup'      => is_scalar($raw_markup) ? (string) $raw_markup : '',
                'source'          => $source,
            );
        }

        return array(
            'total'   => round($total, wc_get_price_decimals()),
            'matches' => $matches,
        );
    }

    /**
     * Build a flexible lookup of selected attributes.
     *
     * @param \WC_Product_Variation $variation           Selected variation.
     * @param array                 $selected_attributes Posted attributes.
     * @return array
     */
    private static function build_selected_attribute_lookup($variation, $selected_attributes) {
        $attributes = array();

        if ($variation instanceof WC_Product_Variation) {
            foreach ($variation->get_attributes() as $attribute_key => $attribute_value) {
                if ('' === trim((string) $attribute_value)) {
                    continue;
                }

                $attributes[$attribute_key] = $attribute_value;
            }
        }

        foreach (self::sanitize_variation_attributes($selected_attributes) as $attribute_key => $attribute_value) {
            $attributes[$attribute_key] = $attribute_value;
        }

        $lookup = array();

        foreach ($attributes as $attribute_key => $attribute_value) {
            $value_variants = self::get_attribute_value_variants($attribute_key, $attribute_value);

            if (empty($value_variants)) {
                continue;
            }

            foreach (self::get_attribute_key_variants($attribute_key) as $lookup_key) {
                if (!isset($lookup[$lookup_key]) || !is_array($lookup[$lookup_key])) {
                    $lookup[$lookup_key] = array();
                }

                foreach ($value_variants as $value_variant) {
                    $lookup[$lookup_key][$value_variant] = true;
                }
            }
        }

        foreach ($lookup as $lookup_key => $value_map) {
            $lookup[$lookup_key] = array_keys($value_map);
        }

        return $lookup;
    }

    /**
     * Return selected global attribute terms with Markup by Attribute metadata support.
     *
     * @param \WC_Product_Variation $variation           Selected variation.
     * @param array                 $selected_attributes Posted attributes.
     * @return array
     */
    private static function get_selected_global_attribute_terms($variation, $selected_attributes) {
        $raw_attributes = array();

        if ($variation instanceof WC_Product_Variation) {
            foreach ($variation->get_attributes() as $attribute_key => $attribute_value) {
                if ('' !== trim((string) $attribute_value)) {
                    $raw_attributes[$attribute_key] = $attribute_value;
                }
            }
        }

        foreach (self::sanitize_variation_attributes($selected_attributes) as $attribute_key => $attribute_value) {
            $raw_attributes[$attribute_key] = $attribute_value;
        }

        $terms = array();

        foreach ($raw_attributes as $attribute_key => $attribute_value) {
            $term = self::resolve_global_attribute_term($attribute_key, $attribute_value);

            if (!$term || is_wp_error($term) || empty($term->taxonomy)) {
                continue;
            }

            $taxonomy = (string) $term->taxonomy;

            $terms[$taxonomy . '|' . $term->term_id] = array(
                'taxonomy'        => $taxonomy,
                'attribute_label' => function_exists('wc_attribute_label') ? wc_attribute_label($taxonomy) : $taxonomy,
                'term_id'         => (int) $term->term_id,
                'term_slug'       => (string) $term->slug,
                'term_name'       => (string) $term->name,
            );
        }

        return array_values($terms);
    }

    /**
     * Return matching value variants for an attribute selection.
     *
     * This supports themes or swatches plugins that send the term slug,
     * visible name or numeric term ID for a selected attribute.
     *
     * @param string $attribute_key   Raw or normalized attribute key.
     * @param string $attribute_value Raw attribute value.
     * @return array
     */
    private static function get_attribute_value_variants($attribute_key, $attribute_value) {
        $raw_value = trim(wc_clean(wp_unslash((string) $attribute_value)));

        if ('' === $raw_value) {
            return array();
        }

        $variants = array();
        $normalized_value = self::normalize_attribute_value($raw_value);

        if ('' !== $normalized_value) {
            $variants[$normalized_value] = $normalized_value;
        }

        if (ctype_digit($raw_value)) {
            $variants[(string) absint($raw_value)] = (string) absint($raw_value);
        }

        $term = self::resolve_global_attribute_term($attribute_key, $raw_value);

        if ($term && !is_wp_error($term)) {
            $term_slug = self::normalize_attribute_value($term->slug);
            $term_name = self::normalize_attribute_value($term->name);

            if ('' !== $term_slug) {
                $variants[$term_slug] = $term_slug;
            }

            if ('' !== $term_name) {
                $variants[$term_name] = $term_name;
            }

            $variants[(string) $term->term_id] = (string) $term->term_id;
        }

        return array_values($variants);
    }

    /**
     * Resolve a selected attribute value to a global attribute term.
     *
     * @param string $attribute_key   Raw or normalized attribute key.
     * @param string $attribute_value Raw attribute value.
     * @return \WP_Term|false
     */
    private static function resolve_global_attribute_term($attribute_key, $attribute_value) {
        $raw_value        = trim(wc_clean(wp_unslash((string) $attribute_value)));
        $normalized_value = self::normalize_attribute_value($raw_value);

        if ('' === $raw_value && '' === $normalized_value) {
            return false;
        }

        foreach (self::get_global_attribute_taxonomy_candidates($attribute_key) as $taxonomy) {
            if (!taxonomy_exists($taxonomy)) {
                continue;
            }

            $term = false;

            if (ctype_digit($raw_value)) {
                $term = get_term_by('id', absint($raw_value), $taxonomy);
            }

            if ((!$term || is_wp_error($term)) && '' !== $normalized_value) {
                $term = get_term_by('slug', $normalized_value, $taxonomy);
            }

            if ((!$term || is_wp_error($term)) && '' !== $raw_value) {
                $term = get_term_by('name', $raw_value, $taxonomy);
            }

            if ($term && !is_wp_error($term)) {
                return $term;
            }
        }

        return false;
    }

    /**
     * Return taxonomy candidates for a selected attribute key.
     *
     * @param string $attribute_key Raw or normalized attribute key.
     * @return array
     */
    private static function get_global_attribute_taxonomy_candidates($attribute_key) {
        $normalized_key = self::normalize_attribute_key($attribute_key);
        $stripped_key   = preg_replace('/^attribute_/', '', $normalized_key);
        $candidates     = array($stripped_key);

        if (0 === strpos($stripped_key, 'pa_')) {
            $without_pa   = substr($stripped_key, 3);
            $candidates[] = $without_pa;
        } else {
            $candidates[] = 'pa_' . $stripped_key;
        }

        return array_values(array_unique(array_filter($candidates)));
    }

    /**
     * Check whether Markup by Attribute for WooCommerce is active.
     *
     * @return bool
     */
    private static function is_markup_by_attribute_active() {
        return defined('MT2MBA_VERSION')
            || defined('MT2MBA_TEXT_DOMAIN')
            || function_exists('mt2Tech\\MarkupByAttribute\\mt2mba_main')
            || class_exists('mt2Tech\\MarkupByAttribute\\Utility\\General');
    }

    /**
     * Return the product-specific amount saved by Markup by Attribute, if any.
     *
     * @param int $product_id Parent product ID.
     * @param int $term_id    Attribute term ID.
     * @return float|null
     */
    private static function get_markup_by_attribute_applied_amount($product_id, $term_id) {
        $meta_value = get_post_meta($product_id, 'mt2mba_' . (int) $term_id . '_markup_amount', true);

        if ('' === trim((string) $meta_value)) {
            return null;
        }

        $amount = self::parse_signed_decimal($meta_value);

        return null === $amount ? null : (float) $amount;
    }

    /**
     * Calculate a Markup by Attribute term amount against the CSV base price.
     *
     * @param string $raw_markup Raw mt2mba_markup value.
     * @param float  $base_price CSV price before markups.
     * @return float|null
     */
    private static function calculate_markup_by_attribute_term_amount($raw_markup, $base_price) {
        $raw_markup = is_scalar($raw_markup) ? trim((string) $raw_markup) : '';

        if ('' === $raw_markup) {
            return null;
        }

        $is_percentage = false !== strpos($raw_markup, '%');
        $numeric_value = self::parse_signed_decimal(str_replace('%', '', $raw_markup));

        if (null === $numeric_value) {
            return null;
        }

        $amount = $is_percentage
            ? ((float) $base_price * (float) $numeric_value) / 100
            : (float) $numeric_value;

        return self::should_round_markup_by_attribute_amount()
            ? round($amount, 0)
            : round($amount, wc_get_price_decimals());
    }

    /**
     * Mirror Markup by Attribute's round-markup option.
     *
     * @return bool
     */
    private static function should_round_markup_by_attribute_amount() {
        if (defined('MT2MBA_ROUND_MARKUP')) {
            return 'yes' === MT2MBA_ROUND_MARKUP;
        }

        return 'yes' === get_option('mt2mba_round_markup', 'no');
    }

    /**
     * Format matched surcharge rules for frontend/cart/order messages.
     *
     * @param array $matches Matched surcharge rules.
     * @return array
     */
    private static function format_attribute_surcharge_match_labels($matches) {
        $labels = array();

        foreach ($matches as $match) {
            if (!isset($match['amount']) || 0.0 === (float) $match['amount']) {
                continue;
            }

            $label = !empty($match['label'])
                ? (string) $match['label']
                : sprintf('%1$s=%2$s', (string) $match['attribute'], (string) $match['value']);
            $mode  = self::sanitize_attribute_surcharge_mode(isset($match['mode']) ? $match['mode'] : 'fixed');

            if ('multiplier' === $mode) {
                $multiplier_text = 'x' . self::format_localized_decimal_text((float) $match['amount'], 4);

                if (isset($match['applied_adjustment'])) {
                    $labels[] = sprintf(
                        '%1$s (%2$s = %3$s)',
                        $label,
                        $multiplier_text,
                        self::format_signed_price_text((float) $match['applied_adjustment'])
                    );
                } else {
                    $labels[] = sprintf('%1$s (%2$s)', $label, $multiplier_text);
                }

                continue;
            }

            $adjustment = isset($match['applied_adjustment']) ? (float) $match['applied_adjustment'] : (float) $match['amount'];
            $labels[] = sprintf('%1$s (%2$s)', $label, self::format_signed_price_text($adjustment));
        }

        return $labels;
    }

    /**
     * Format matched Markup by Attribute adjustments.
     *
     * @param array $matches Matched markup rules.
     * @return array
     */
    private static function format_markup_by_attribute_match_labels($matches) {
        $labels = array();

        foreach ($matches as $match) {
            if (!isset($match['amount']) || 0.0 === (float) $match['amount']) {
                continue;
            }

            $attribute_label = !empty($match['attribute_label']) ? (string) $match['attribute_label'] : __('Atributo', 'woo-variable-pricing-csv');
            $term_name       = !empty($match['term_name']) ? (string) $match['term_name'] : (string) $match['term_slug'];

            $labels[] = sprintf(
                /* translators: 1: attribute label, 2: term name, 3: signed markup amount */
                __('%1$s: %2$s (%3$s)', 'woo-variable-pricing-csv'),
                $attribute_label,
                $term_name,
                self::format_signed_price_text((float) $match['amount'])
            );
        }

        return $labels;
    }

    /**
     * Format a generic decimal number using localized separators.
     *
     * @param float $number    Numeric value.
     * @param int   $precision Max decimals to keep.
     * @return string
     */
    private static function format_localized_decimal_text($number, $precision = 4) {
        $formatted = number_format((float) $number, max(0, (int) $precision), '.', '');
        $formatted = rtrim(rtrim($formatted, '0'), '.');

        if ('' === $formatted) {
            $formatted = '0';
        }

        if (function_exists('wc_format_localized_decimal')) {
            return wc_format_localized_decimal($formatted);
        }

        return str_replace('.', ',', $formatted);
    }

    /**
     * Convert a price HTML fragment into clean text.
     *
     * @param float $amount Price amount.
     * @return string
     */
    private static function format_price_text($amount) {
        $price_html = function_exists('wc_price') ? wc_price($amount) : (string) $amount;
        $charset    = function_exists('get_bloginfo') ? get_bloginfo('charset') : 'UTF-8';

        return html_entity_decode(wp_strip_all_tags($price_html), ENT_QUOTES, $charset ? $charset : 'UTF-8');
    }

    /**
     * Format a signed adjustment amount.
     *
     * @param float $amount Adjustment amount.
     * @return string
     */
    private static function format_signed_price_text($amount) {
        $sign = $amount < 0 ? '-' : '+';

        return $sign . self::format_price_text(abs((float) $amount));
    }

    /**
     * Determine the CSV delimiter from the first line.
     *
     * @param string $line First line of the CSV.
     * @return string
     */
    private static function detect_delimiter($line) {
        $delimiters = array(',', ';', "\t");
        $winner     = ',';
        $best_count = 0;

        foreach ($delimiters as $delimiter) {
            $fields = str_getcsv($line, $delimiter);
            $count  = is_array($fields) ? count($fields) : 0;

            if ($count > $best_count) {
                $best_count = $count;
                $winner     = $delimiter;
            }
        }

        return $winner;
    }

    /**
     * Determine if the CSV contains width/height columns.
     *
     * @param array $headers Normalized headers.
     * @return bool
     */
    private static function has_dimension_headers($headers) {
        $has_width  = count(array_intersect($headers, array('width', 'width_cm', 'width_mm', 'min_width_cm', 'max_width_cm', 'min_width_mm', 'max_width_mm'))) > 0;
        $has_height = count(array_intersect($headers, array('height', 'height_cm', 'height_mm', 'min_height_cm', 'max_height_cm', 'min_height_mm', 'max_height_mm'))) > 0;

        return $has_width && $has_height;
    }

    /**
     * Determine if the CSV contains pricing columns.
     *
     * @param array $headers Normalized headers.
     * @return bool
     */
    private static function has_pricing_headers($headers) {
        return count(array_intersect($headers, array('price', 'fixed_price', 'price_per_m2'))) > 0;
    }

    /**
     * Normalize a CSV header into a canonical key.
     *
     * @param string $header Raw header.
     * @return string
     */
    private static function canonicalize_header($header) {
        $header = self::clean_cell($header);
        $header = strtolower($header);
        $header = str_replace(array('-', ' ', ':'), '_', $header);
        $header = preg_replace('/[^a-z0-9_]/', '_', $header);
        $header = preg_replace('/_+/', '_', $header);
        $header = trim($header, '_');

        $aliases = array(
            'variationid'         => 'variation_id',
            'variacion_id'        => 'variation_id',
            'id_variacion'        => 'variation_id',
            'widht'               => 'width',
            'width'               => 'width',
            'width_cm'            => 'width_cm',
            'heigth'              => 'height',
            'height'              => 'height',
            'height_cm'           => 'height_cm',
            'ancho_cm'            => 'width_cm',
            'alto_cm'             => 'height_cm',
            'ancho_min_cm'        => 'min_width_cm',
            'ancho_max_cm'        => 'max_width_cm',
            'alto_min_cm'         => 'min_height_cm',
            'alto_max_cm'         => 'max_height_cm',
            'min_ancho_cm'        => 'min_width_cm',
            'max_ancho_cm'        => 'max_width_cm',
            'min_alto_cm'         => 'min_height_cm',
            'max_alto_cm'         => 'max_height_cm',
            'ancho_mm'            => 'width_mm',
            'alto_mm'             => 'height_mm',
            'ancho_min_mm'        => 'min_width_mm',
            'ancho_max_mm'        => 'max_width_mm',
            'alto_min_mm'         => 'min_height_mm',
            'alto_max_mm'         => 'max_height_mm',
            'min_ancho_mm'        => 'min_width_mm',
            'max_ancho_mm'        => 'max_width_mm',
            'min_alto_mm'         => 'min_height_mm',
            'max_alto_mm'         => 'max_height_mm',
            'precio'              => 'price',
            'precio_fijo'         => 'fixed_price',
            'precio_m2'           => 'price_per_m2',
            'tarifa_m2'           => 'price_per_m2',
            'precio_base'         => 'base_price',
            'precio_minimo'       => 'min_price',
            'nombre_tarifa'       => 'label',
            'tarifa'              => 'label',
        );

        return isset($aliases[$header]) ? $aliases[$header] : $header;
    }

    /**
     * Clean a raw CSV value.
     *
     * @param string $value Raw value.
     * @return string
     */
    public static function clean_cell($value) {
        $value = (string) $value;
        $value = preg_replace('/^\xEF\xBB\xBF/', '', $value);
        return trim(wp_unslash($value));
    }

    /**
     * Check whether a CSV row is empty.
     *
     * @param array $row Row values.
     * @return bool
     */
    private static function is_blank_row($row) {
        foreach ($row as $value) {
            if ('' !== self::clean_cell($value)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Return the first non-empty value among a set of columns.
     *
     * @param array $row     CSV row.
     * @param array $columns Candidate columns.
     * @return string|null
     */
    private static function first_non_empty_value($row, $columns) {
        foreach ($columns as $column) {
            if (isset($row[$column]) && '' !== trim((string) $row[$column])) {
                return (string) $row[$column];
            }
        }

        return null;
    }

    /**
     * Parse a positive integer from CSV text.
     *
     * @param string|null $value Raw value.
     * @param string      $label Field label.
     * @return int|\WP_Error
     */
    private static function parse_positive_integer($value, $label) {
        $value = null !== $value ? trim((string) $value) : '';

        if ('' === $value) {
            return new WP_Error('wvpc_integer_empty', sprintf(__('El campo %s está vacío.', 'woo-variable-pricing-csv'), $label));
        }

        if (ctype_digit($value)) {
            $number = absint($value);
        } else {
            $number = self::parse_decimal($value, $label);

            if (is_wp_error($number) || abs((float) $number - round((float) $number)) > 0.00001) {
                return new WP_Error('wvpc_integer_invalid', sprintf(__('El campo %1$s debe ser un entero positivo en milímetros: %2$s', 'woo-variable-pricing-csv'), $label, $value));
            }

            $number = (int) round((float) $number);
        }

        if ($number < 1) {
            return new WP_Error('wvpc_integer_zero', sprintf(__('El campo %s debe ser mayor que cero.', 'woo-variable-pricing-csv'), $label));
        }

        return $number;
    }

    /**
     * Parse an exact dimension value already expressed in millimeters.
     *
     * The Width / Height columns must contain values in mm.
     * No unit conversion is performed; the raw numeric value is returned as-is.
     *
     * @param string|null $value Raw value in mm.
     * @param string      $label Field label for error messages.
     * @return int|\WP_Error
     */
    private static function parse_exact_dimension_mm($value, $label) {
        $dimension = self::parse_decimal($value, $label);

        if (is_wp_error($dimension)) {
            return $dimension;
        }

        $mm_value = (int) round((float) $dimension);

        if ($mm_value < 1) {
            return new WP_Error(
                'wvpc_exact_dimension_invalid',
                sprintf(
                    __('El campo %s debe ser un número positivo expresado en milímetros.', 'woo-variable-pricing-csv'),
                    $label
                )
            );
        }

        return $mm_value;
    }

    /**
     * Parse a dimension explicitly expressed in centimeters and convert it to mm.
     *
     * @param string|null $value Raw value in cm.
     * @param string      $label Field label for error messages.
     * @return int|\WP_Error
     */
    private static function parse_centimeters_to_mm($value, $label) {
        $dimension = self::parse_decimal($value, $label);

        if (is_wp_error($dimension)) {
            return $dimension;
        }

        $mm_value = ((float) $dimension) * 10;

        if (abs($mm_value - round($mm_value)) > 0.00001 || $mm_value < 1) {
            return new WP_Error(
                'wvpc_exact_dimension_invalid_cm',
                sprintf(
                    __('El campo %s debe ser un número positivo expresado en centímetros válidos, con un máximo de un decimal.', 'woo-variable-pricing-csv'),
                    $label
                )
            );
        }

        return (int) round($mm_value);
    }

    /**
     * Parse values declared in *_cm columns while keeping compatibility with CSVs
     * whose real unit is configured in the product settings.
     *
     * All numeric values follow the configured CSV unit. This keeps compatibility with
     * historical files uploaded in millimeters even when Excel exported cells such as
     * 600,00 or 800,00 with decimal formatting.
     *
     * @param string|null $value         Raw value from an explicit centimeter column.
     * @param string      $label         Field label for error messages.
     * @param string      $fallback_unit Configured CSV unit for integer values.
     * @return int|\WP_Error
     */
    private static function parse_explicit_centimeters_or_legacy_millimeters_to_mm($value, $label, $fallback_unit = 'cm') {
        $raw_value     = null !== $value ? trim((string) $value) : '';
        $normalized    = self::normalize_localized_number_string($raw_value);
        $fallback_unit = self::sanitize_measurement_unit($fallback_unit, 'cm');

        if ('' === $normalized) {
            return new WP_Error('wvpc_decimal_empty', sprintf(__('El campo %s está vacío.', 'woo-variable-pricing-csv'), $label));
        }

        if ('mm' === $fallback_unit) {
            return self::parse_exact_dimension_mm($raw_value, $label);
        }

        return self::parse_centimeters_to_mm($raw_value, $label);
    }

    /**
     * Parse the legacy Width/Height columns keeping compatibility with old CSVs.
     *
     * The configured CSV unit is authoritative, including files exported by Excel
     * with decimal formatting such as 600,00 or 800,00.
     *
     * @param string|null $value         Raw value from Width/Height.
     * @param string      $label         Field label for error messages.
     * @param string      $inferred_unit Inferred unit based on row content.
     * @param string      $fallback_unit Configured CSV unit for integer legacy values.
     * @return int|\WP_Error
     */
    private static function parse_legacy_exact_dimension_to_mm($value, $label, $inferred_unit = 'auto', $fallback_unit = 'mm') {
        $raw_value     = null !== $value ? trim((string) $value) : '';
        $normalized    = self::normalize_localized_number_string($raw_value);
        $fallback_unit = self::sanitize_csv_unit($fallback_unit);

        if ('' === $normalized) {
            return new WP_Error('wvpc_decimal_empty', sprintf(__('El campo %s está vacío.', 'woo-variable-pricing-csv'), $label));
        }

        if ('cm' === $inferred_unit) {
            return self::parse_centimeters_to_mm($raw_value, $label);
        }

        if ('mm' === $inferred_unit) {
            return self::parse_exact_dimension_mm($raw_value, $label);
        }

        if (preg_match('/^\d+$/', $normalized)) {
            if ('cm' === $fallback_unit) {
                return self::parse_centimeters_to_mm($raw_value, $label);
            }

            return self::parse_exact_dimension_mm($raw_value, $label);
        }

        return self::parse_centimeters_to_mm($raw_value, $label);
    }

    /**
     * Infer the intended unit for legacy Width/Height columns without explicit suffixes.
     *
     * The configured CSV unit is authoritative here so legacy Width / Height files can
     * be imported reliably in either millimeters or centimeters.
     *
     * @param array  $row             CSV row.
     * @param string $configured_unit Configured CSV unit.
     * @return string One of auto|cm|mm.
     */
    private static function infer_legacy_exact_dimension_unit($row, $configured_unit = 'mm') {
        $configured_unit = self::sanitize_csv_unit($configured_unit);
        $legacy_values = array();

        foreach (array('width', 'height') as $column) {
            if (empty($row[$column]) || isset($row[$column . '_cm']) || isset($row[$column . '_mm'])) {
                continue;
            }

            $legacy_values[] = trim((string) $row[$column]);
        }

        if (empty($legacy_values)) {
            return 'auto';
        }

        return $configured_unit;
    }

    /**
     * Parse a decimal value from CSV text.
     *
     * @param string|null $value Raw value.
     * @param string      $label Field label.
     * @return float|\WP_Error
     */
    private static function parse_decimal($value, $label) {
        $raw_value = null !== $value ? trim((string) $value) : '';
        $value     = self::normalize_localized_number_string($raw_value);

        if ('' === $value) {
            return new WP_Error('wvpc_decimal_empty', sprintf(__('El campo %s está vacío.', 'woo-variable-pricing-csv'), $label));
        }

        if (!is_numeric($value)) {
            return new WP_Error('wvpc_decimal_invalid', sprintf(__('El campo %1$s no tiene un número válido: %2$s', 'woo-variable-pricing-csv'), $label, $raw_value));
        }

        $number = (float) $value;

        if ($number < 0) {
            return new WP_Error('wvpc_decimal_negative', sprintf(__('El campo %s no puede ser negativo.', 'woo-variable-pricing-csv'), $label));
        }

        return $number;
    }

    /**
     * Parse a signed decimal value for external attribute markups.
     *
     * @param string|null $value Raw value.
     * @return float|null
     */
    private static function parse_signed_decimal($value) {
        $normalized = self::normalize_localized_number_string($value);

        if ('' === $normalized || '-' === $normalized || !is_numeric($normalized)) {
            return null;
        }

        return (float) $normalized;
    }

    /**
     * Parse an optional decimal, defaulting to zero.
     *
     * @param string|null $value Raw value.
     * @param string      $label Field label.
     * @return float|\WP_Error
     */
    private static function parse_optional_decimal($value, $label) {
        if (null === $value || '' === trim((string) $value)) {
            return 0.0;
        }

        return self::parse_decimal($value, $label);
    }

    /**
     * Parse an optional price decimal, defaulting to zero.
     *
     * @param string|null $value Raw value.
     * @param string      $label Field label.
     * @return float|\WP_Error
     */
    private static function parse_optional_price_decimal($value, $label) {
        if (null === $value || '' === trim((string) $value)) {
            return 0.0;
        }

        return self::parse_price_decimal($value, $label);
    }

    /**
     * Parse a decimal that may legitimately be empty.
     *
     * @param string|null $value Raw value.
     * @param string      $label Field label.
     * @return float|null|\WP_Error
     */
    private static function parse_nullable_decimal($value, $label) {
        if (null === $value || '' === trim((string) $value)) {
            return null;
        }

        return self::parse_decimal($value, $label);
    }

    /**
     * Parse a price decimal that may legitimately be empty.
     *
     * @param string|null $value Raw value.
     * @param string      $label Field label.
     * @return float|null|\WP_Error
     */
    private static function parse_nullable_price_decimal($value, $label) {
        if (null === $value || '' === trim((string) $value)) {
            return null;
        }

        return self::parse_price_decimal($value, $label);
    }

    /**
     * Read a posted measurement field, preferring centimeters and supporting legacy mm fields.
     *
     * @param string $dimension width|height.
     * @return string
     */
    private static function get_posted_measurement($dimension) {
        $centimeter_key = 'wvpc_' . $dimension . '_cm';

        if (isset($_POST[$centimeter_key])) {
            return trim((string) wp_unslash($_POST[$centimeter_key]));
        }

        $legacy_millimeter_key = 'wvpc_' . $dimension . '_mm';

        if (isset($_POST[$legacy_millimeter_key])) {
            $legacy_mm = trim((string) wp_unslash($_POST[$legacy_millimeter_key]));

            if ('' === $legacy_mm) {
                return '';
            }

            return self::convert_millimeters_input_to_centimeters_input($legacy_mm);
        }

        return '';
    }

    /**
     * Read a request measurement field, preferring centimeters and supporting legacy mm payloads.
     *
     * @param string $dimension width|height.
     * @return string
     */
    private static function get_request_measurement($dimension) {
        $centimeter_keys = array(
            $dimension . '_cm',
            'wvpc_' . $dimension . '_cm',
        );

        foreach ($centimeter_keys as $centimeter_key) {
            if (isset($_POST[$centimeter_key])) {
                return trim((string) wp_unslash($_POST[$centimeter_key]));
            }
        }

        $legacy_millimeter_keys = array(
            $dimension . '_mm',
            'wvpc_' . $dimension . '_mm',
        );

        foreach ($legacy_millimeter_keys as $legacy_millimeter_key) {
            if (!isset($_POST[$legacy_millimeter_key])) {
                continue;
            }

            $legacy_mm = trim((string) wp_unslash($_POST[$legacy_millimeter_key]));

            if ('' === $legacy_mm) {
                return '';
            }

            return self::convert_millimeters_input_to_centimeters_input($legacy_mm);
        }

        return '';
    }

    /**
     * Format millimeters as a centimeter string for HTML number inputs.
     *
     * @param int|string $value_mm Stored millimeters.
     * @return string
     */
    public static function format_mm_as_cm_input($value_mm) {
        $cm_value = ((float) $value_mm) / 10;

        if (abs($cm_value - round($cm_value)) < 0.00001) {
            return (string) (int) round($cm_value);
        }

        return rtrim(rtrim(number_format($cm_value, 1, '.', ''), '0'), '.');
    }

    /**
     * Format millimeters as a human-readable centimeter string.
     *
     * @param int|string $value_mm Stored millimeters.
     * @return string
     */
    public static function format_mm_as_cm_text($value_mm) {
        $formatted = self::format_mm_as_cm_input($value_mm);

        if (function_exists('wc_format_localized_decimal')) {
            return wc_format_localized_decimal($formatted);
        }

        return str_replace('.', ',', $formatted);
    }

    /**
     * Sanitize the configured storefront display unit.
     *
     * @param string|null $unit Raw unit value.
     * @return string
     */
    public static function sanitize_display_unit($unit) {
        return self::sanitize_measurement_unit($unit, 'cm');
    }

    /**
     * Sanitize the configured CSV import unit.
     *
     * @param string|null $unit Raw unit value.
     * @return string
     */
    public static function sanitize_csv_unit($unit) {
        return self::sanitize_measurement_unit($unit, 'mm');
    }

    /**
     * Sanitize a measurement unit using the provided default.
     *
     * @param string|null $unit         Raw unit value.
     * @param string      $default_unit Default unit when the value is invalid.
     * @return string
     */
    private static function sanitize_measurement_unit($unit, $default_unit = 'cm') {
        $normalized   = strtolower((string) $unit);
        $default_unit = ('mm' === strtolower((string) $default_unit)) ? 'mm' : 'cm';

        if ('mm' === $normalized || 'cm' === $normalized) {
            return $normalized;
        }

        return $default_unit;
    }

    /**
     * Return the configured display unit from product settings.
     *
     * @param array $settings Product settings.
     * @return string
     */
    private static function get_settings_display_unit($settings) {
        return self::sanitize_display_unit(isset($settings['display_unit']) ? $settings['display_unit'] : 'cm');
    }

    /**
     * Return the configured CSV import unit from product settings.
     *
     * @param array $settings Product settings.
     * @return string
     */
    private static function get_settings_csv_unit($settings) {
        return self::sanitize_csv_unit(isset($settings['csv_unit']) ? $settings['csv_unit'] : 'mm');
    }

    /**
     * Return the short unit suffix used next to measurements.
     *
     * @param string $display_unit Display unit.
     * @return string
     */
    private static function get_display_unit_suffix($display_unit) {
        return self::sanitize_display_unit($display_unit);
    }

    /**
     * Return the localized unit name used in helper texts.
     *
     * @param string $display_unit Display unit.
     * @return string
     */
    private static function get_display_unit_name($display_unit) {
        return ('mm' === self::sanitize_display_unit($display_unit))
            ? __('milímetros', 'woo-variable-pricing-csv')
            : __('centímetros', 'woo-variable-pricing-csv');
    }

    /**
     * Format stored millimeters for visible inputs in the selected display unit.
     *
     * @param int|string $value_mm Stored millimeters.
     * @param string     $display_unit Display unit.
     * @return string
     */
    private static function format_mm_for_display_input($value_mm, $display_unit) {
        if ('mm' === self::sanitize_display_unit($display_unit)) {
            return (string) max(0, (int) round((float) $value_mm));
        }

        return self::format_mm_as_cm_input($value_mm);
    }

    /**
     * Format stored millimeters for visible text in the selected display unit.
     *
     * @param int|string $value_mm Stored millimeters.
     * @param string     $display_unit Display unit.
     * @return string
     */
    private static function format_mm_for_display_text($value_mm, $display_unit) {
        if ('mm' === self::sanitize_display_unit($display_unit)) {
            return (string) max(0, (int) round((float) $value_mm));
        }

        return self::format_mm_as_cm_text($value_mm);
    }

    /**
     * Format a measurement with the selected unit suffix.
     *
     * @param int|string $value_mm Stored millimeters.
     * @param string     $display_unit Display unit.
     * @return string
     */
    private static function format_measurement_with_unit($value_mm, $display_unit) {
        return sprintf('%1$s %2$s', self::format_mm_for_display_text($value_mm, $display_unit), self::get_display_unit_suffix($display_unit));
    }

    /**
     * Read a posted measurement value in the currently visible unit.
     *
     * @param string $dimension width|height.
     * @param string $display_unit Display unit.
     * @return string
     */
    private static function get_display_measurement_value($dimension, $display_unit) {
        $display_unit = self::sanitize_display_unit($display_unit);

        if ('cm' === $display_unit) {
            return self::get_posted_measurement($dimension);
        }

        $millimeter_key = 'wvpc_' . $dimension . '_mm';

        if (isset($_POST[$millimeter_key])) {
            return trim((string) wp_unslash($_POST[$millimeter_key]));
        }

        $centimeter_key = 'wvpc_' . $dimension . '_cm';

        if (isset($_POST[$centimeter_key])) {
            return self::convert_centimeters_input_to_millimeters_input(wp_unslash($_POST[$centimeter_key]));
        }

        return '';
    }

    /**
     * Resolve the display unit stored on a cart line item.
     *
     * @param array $cart_item Cart item.
     * @return string
     */
    private static function get_cart_item_display_unit($cart_item) {
        if (!empty($cart_item['wvpc_measurement_data']['display_unit'])) {
            return self::sanitize_display_unit($cart_item['wvpc_measurement_data']['display_unit']);
        }

        if (!empty($cart_item['product_id'])) {
            return self::get_settings_display_unit(self::get_product_settings((int) $cart_item['product_id']));
        }

        if (!empty($cart_item['data']) && $cart_item['data'] instanceof WC_Product) {
            return self::get_settings_display_unit(self::get_product_settings((int) $cart_item['data']->get_id()));
        }

        return 'cm';
    }

    /**
     * Resolve the display unit for order item measurement meta.
     *
     * @param \WC_Order_Item_Product $item Order item.
     * @return string
     */
    private static function get_order_item_display_unit($item) {
        if ($item instanceof WC_Order_Item_Product) {
            $raw_measurement_data = $item->get_meta(self::ORDER_META_DATA, true);

            if (is_string($raw_measurement_data) && '' !== $raw_measurement_data) {
                $measurement_data = json_decode($raw_measurement_data, true);

                if (is_array($measurement_data) && !empty($measurement_data['display_unit'])) {
                    return self::sanitize_display_unit($measurement_data['display_unit']);
                }
            }

            $product_id = (int) $item->get_product_id();

            if ($product_id > 0) {
                return self::get_settings_display_unit(self::get_product_settings($product_id));
            }
        }

        return 'cm';
    }

    /**
     * Convert a posted millimeter input into the centimeter string expected by the price engine.
     *
     * @param mixed $value_mm Raw millimeter input.
     * @return string
     */
    private static function convert_millimeters_input_to_centimeters_input($value_mm) {
        $raw_value  = trim((string) $value_mm);
        $normalized = self::normalize_localized_number_string($raw_value);

        if ('' === $normalized || !is_numeric($normalized)) {
            return $raw_value;
        }

        $centimeters = ((float) $normalized) / 10;

        return rtrim(rtrim(number_format($centimeters, 4, '.', ''), '0'), '.');
    }

    /**
     * Convert a posted centimeter input into a millimeter string for visible mm fields.
     *
     * @param mixed $value_cm Raw centimeter input.
     * @return string
     */
    private static function convert_centimeters_input_to_millimeters_input($value_cm) {
        $raw_value  = trim((string) $value_cm);
        $normalized = self::normalize_localized_number_string($raw_value);

        if ('' === $normalized || !is_numeric($normalized)) {
            return $raw_value;
        }

        $millimeters = ((float) $normalized) * 10;

        return rtrim(rtrim(number_format($millimeters, 4, '.', ''), '0'), '.');
    }

    /**
     * Parse a price value using WooCommerce decimal normalization.
     *
     * @param string|null $value Raw value.
     * @param string      $label Field label.
     * @return float|\WP_Error
     */
    private static function parse_price_decimal($value, $label) {
        $raw_value  = null !== $value ? trim((string) $value) : '';
        $normalized = self::normalize_localized_number_string($raw_value);

        if ('' === $normalized) {
            return new WP_Error('wvpc_price_empty', sprintf(__('El campo %s está vacío.', 'woo-variable-pricing-csv'), $label));
        }

        if ('' === $normalized || !is_numeric($normalized)) {
            return new WP_Error('wvpc_price_invalid', sprintf(__('El campo %1$s no tiene un precio válido: %2$s', 'woo-variable-pricing-csv'), $label, $raw_value));
        }

        $number = (float) $normalized;

        if ($number < 0) {
            return new WP_Error('wvpc_price_negative', sprintf(__('El campo %s no puede ser negativo.', 'woo-variable-pricing-csv'), $label));
        }

        return $number;
    }

    /**
     * Normalize localized numeric strings before parsing them as floats.
     *
     * @param string|null $value Raw value.
     * @return string
     */
    public static function normalize_localized_number_string($value) {
        $value = null !== $value ? trim((string) $value) : '';
        $value = preg_replace('/[^\d,\.\-]/', '', $value);

        if ('' === $value) {
            return '';
        }

        $is_negative = '-' === substr($value, 0, 1);
        $value       = str_replace('-', '', $value);

        if ('' === $value) {
            return $is_negative ? '-' : '';
        }

        if (false !== strpos($value, ',') && false !== strpos($value, '.')) {
            $last_comma        = strrpos($value, ',');
            $last_dot          = strrpos($value, '.');
            $decimal_separator = $last_comma > $last_dot ? ',' : '.';
            $parts             = explode($decimal_separator, $value);
            $fractional_part   = array_pop($parts);
            $integer_part      = implode('', $parts);
            $integer_part      = str_replace(array(',', '.'), '', $integer_part);
            $fractional_part   = str_replace(array(',', '.'), '', $fractional_part);
            $normalized        = '' !== $integer_part ? $integer_part : '0';

            if ('' !== $fractional_part) {
                $normalized .= '.' . $fractional_part;
            }

            return ($is_negative ? '-' : '') . $normalized;
        }

        if (false !== strpos($value, ',')) {
            $value = self::normalize_single_separator_number_string($value, ',');
        } elseif (false !== strpos($value, '.')) {
            $value = self::normalize_single_separator_number_string($value, '.');
        }

        return ($is_negative ? '-' : '') . $value;
    }

    /**
     * Normalize stored order measurement meta from multiple historical formats to mm.
     *
     * @param mixed $value Raw stored meta value.
     * @return int
     */
    private static function normalize_stored_order_measurement_to_mm($value) {
        $raw_value = trim(wp_strip_all_tags((string) $value));

        if ('' === $raw_value) {
            return 0;
        }

        if (preg_match('/cm$/i', $raw_value)) {
            $normalized = self::normalize_localized_number_string(preg_replace('/cm$/i', '', $raw_value));

            if (!is_numeric($normalized)) {
                return 0;
            }

            $millimeters = ((float) $normalized) * 10;

            return $millimeters > 0 ? (int) round($millimeters) : 0;
        }

        if (preg_match('/mm$/i', $raw_value)) {
            $normalized = self::normalize_localized_number_string(preg_replace('/mm$/i', '', $raw_value));

            if (!is_numeric($normalized)) {
                return 0;
            }

            return max(0, (int) round((float) $normalized));
        }

        $normalized = self::normalize_localized_number_string($raw_value);

        if (!is_numeric($normalized)) {
            return 0;
        }

        return max(0, (int) round((float) $normalized));
    }

    /**
     * Normalize numeric strings that use only one separator type.
     *
     * Disambiguation rules for a single separator with exactly 3 trailing digits:
     *   - Multiple occurrences of the separator  → thousands separator (e.g. 1.000.500 → 1000500).
     *   - Single occurrence AND the integer part is empty (e.g. .500) → decimal separator.
     *   - Single occurrence AND the integer part is '0' literally (e.g. 0.500) → decimal separator.
     *   - Single occurrence AND the integer part has more than 3 digits (e.g. 1000.500) → decimal.
     *   - Otherwise (e.g. 1.500) → treated as thousands separator to match common European price
     *     formats (1.500 = 1500 €).  If your prices genuinely have three decimal places, use
     *     the width_mm / height_mm column names (which expect integers) or add a leading zero
     *     (0.500) to force decimal interpretation.
     *
     * @param string $value     Raw numeric string (no sign, already stripped).
     * @param string $separator The single separator character found in the string.
     * @return string
     */
    private static function normalize_single_separator_number_string($value, $separator) {
        $parts = explode($separator, $value);

        if (count($parts) < 2) {
            return $value;
        }

        $fractional_part = array_pop($parts);
        $integer_part    = implode('', $parts);
        $separator_count = count($parts);

        if ('' === $integer_part) {
            $integer_part = '0';
        }

        if ('' === $fractional_part) {
            return $integer_part;
        }

        // Multiple separators → all are thousands separators (e.g. 1.000.500).
        if ($separator_count > 1) {
            return strlen($fractional_part) <= 2
                ? $integer_part . '.' . $fractional_part
                : $integer_part . $fractional_part;
        }

        // Single separator from here on.
        $frac_len = strlen($fractional_part);

        // Not exactly 3 digits after separator → unambiguously decimal.
        if (3 !== $frac_len) {
            return $frac_len <= 2
                ? $integer_part . '.' . $fractional_part
                : $integer_part . '.' . $fractional_part;
        }

        // Exactly 3 digits after a single separator.
        // Treat as decimal if the integer part is empty/zero or has >3 digits.
        if ('0' === $integer_part || strlen($integer_part) > 3) {
            return $integer_part . '.' . $fractional_part;
        }

        // Otherwise treat as thousands separator (e.g. 1.500 → 1500).
        return $integer_part . $fractional_part;
    }

    /**
     * Normalize an attribute key to WooCommerce's attribute_* shape.
     *
     * @param string $attribute_key Raw attribute key.
     * @return string
     */
    private static function normalize_attribute_key($attribute_key) {
        $normalized_key = self::canonicalize_header($attribute_key);

        if ('' === $normalized_key) {
            return '';
        }

        if (0 !== strpos($normalized_key, 'attribute_')) {
            $normalized_key = 'attribute_' . ltrim($normalized_key, '_');
        }

        return $normalized_key;
    }

    /**
     * Return key variants so admin rules can use pa_tejido, tejido or attribute_pa_tejido.
     *
     * @param string $attribute_key Raw or normalized key.
     * @return array
     */
    private static function get_attribute_key_variants($attribute_key) {
        $normalized_key = self::normalize_attribute_key($attribute_key);

        if ('' === $normalized_key) {
            return array();
        }

        $stripped_key = preg_replace('/^attribute_/', '', $normalized_key);
        $variants     = array($normalized_key, $stripped_key, 'attribute_' . $stripped_key);

        if (0 === strpos($stripped_key, 'pa_')) {
            $without_pa = substr($stripped_key, 3);

            if ('' !== $without_pa) {
                $variants[] = $without_pa;
                $variants[] = 'attribute_' . $without_pa;
            }
        } else {
            $variants[] = 'pa_' . $stripped_key;
            $variants[] = 'attribute_pa_' . $stripped_key;
        }

        return array_values(array_unique(array_filter($variants)));
    }

    /**
     * Normalize attribute values for matching.
     *
     * @param string $value Raw attribute value.
     * @return string
     */
    private static function normalize_attribute_value($value) {
        return sanitize_title(wc_clean(wp_strip_all_tags((string) $value)));
    }

    /**
     * Sanitize variation attributes coming from frontend requests.
     *
     * @param array $attributes Raw attributes.
     * @return array
     */
    private static function sanitize_variation_attributes($attributes) {
        $sanitized = array();

        if (!is_array($attributes)) {
            return $sanitized;
        }

        foreach ($attributes as $key => $value) {
            if (is_array($value)) {
                continue;
            }

            $normalized_key = self::canonicalize_header((string) $key);

            if ('' === $normalized_key) {
                continue;
            }

            if (0 !== strpos($normalized_key, 'attribute_')) {
                $normalized_key = 'attribute_' . ltrim($normalized_key, '_');
            }

            $clean_value = trim(wc_clean(wp_unslash((string) $value)));

            if ('' === $clean_value) {
                continue;
            }

            $sanitized[$normalized_key] = self::normalize_attribute_value($clean_value);
        }

        return $sanitized;
    }

    /**
     * Collect posted variation attributes from the request.
     *
     * @return array
     */
    private static function get_posted_variation_attributes() {
        $attributes = array();

        foreach ($_POST as $key => $value) {
            $key = (string) $key;

            if (0 !== strpos($key, 'attribute_') || is_array($value)) {
                continue;
            }

            $attributes[$key] = $value;
        }

        return self::sanitize_variation_attributes($attributes);
    }

    /**
     * Resolve the selected variation from the hidden variation ID or attributes.
     *
     * @param \WC_Product $product             Variable product.
     * @param int         $variation_id        Posted variation ID.
     * @param array       $selected_attributes Selected attributes.
     * @return int
     */
    private static function resolve_selected_variation_id($product, $variation_id, $selected_attributes) {
        $variation_id = absint($variation_id);

        if ($variation_id > 0) {
            $variation = wc_get_product($variation_id);

            if ($variation && ($variation instanceof WC_Product_Variation) && (int) $variation->get_parent_id() === (int) $product->get_id()) {
                return $variation_id;
            }
        }

        return self::find_matching_variation_from_attributes($product, $selected_attributes);
    }

    /**
     * Resolve a variation ID from the currently selected attributes.
     *
     * @param \WC_Product $product             Variable product.
     * @param array       $selected_attributes Selected attributes.
     * @return int
     */
    private static function find_matching_variation_from_attributes($product, $selected_attributes) {
        $selected_attributes = self::sanitize_variation_attributes($selected_attributes);

        if (empty($selected_attributes)) {
            return 0;
        }

        if (class_exists('WC_Data_Store')) {
            $data_store = WC_Data_Store::load('product');

            if ($data_store && is_callable(array($data_store, 'find_matching_product_variation'))) {
                $matched_variation_id = $data_store->find_matching_product_variation($product, $selected_attributes);

                if ($matched_variation_id) {
                    return (int) $matched_variation_id;
                }
            }
        }

        $matches = array();

        foreach ($product->get_children() as $child_id) {
            $variation = wc_get_product($child_id);

            if (!$variation || !($variation instanceof WC_Product_Variation)) {
                continue;
            }

            if (self::row_matches_variation($variation->get_attributes(), $selected_attributes)) {
                $matches[] = (int) $child_id;
            }
        }

        return 1 === count($matches) ? $matches[0] : 0;
    }

    /**
     * Return reserved CSV columns that are not attributes.
     *
     * @return array
     */
    private static function get_reserved_columns() {
        return array(
            'variation_id',
            'sku',
            'width',
            'height',
            'width_cm',
            'height_cm',
            'width_mm',
            'height_mm',
            'min_width_cm',
            'max_width_cm',
            'min_height_cm',
            'max_height_cm',
            'min_width_mm',
            'max_width_mm',
            'min_height_mm',
            'max_height_mm',
            'price',
            'fixed_price',
            'price_per_m2',
            'base_price',
            'min_price',
            'label',
        );
    }

    /**
     * Sort matching rules by specificity and the smallest covering breakpoint.
     *
     * @param array $left  First rule.
     * @param array $right Second rule.
     * @return int
     */
    private static function compare_matching_rules($left, $right) {
        $left_mode  = isset($left['lookup_mode']) ? (string) $left['lookup_mode'] : 'range';
        $right_mode = isset($right['lookup_mode']) ? (string) $right['lookup_mode'] : 'range';

        if ($left_mode !== $right_mode) {
            return ('range' === $left_mode) ? -1 : 1;
        }

        if ('matrix' === $left_mode) {
            $compare = ((int) $left['max_width_mm']) <=> ((int) $right['max_width_mm']);

            if (0 !== $compare) {
                return $compare;
            }

            $compare = ((int) $left['max_height_mm']) <=> ((int) $right['max_height_mm']);

            if (0 !== $compare) {
                return $compare;
            }

            return (((int) $left['max_width_mm'] * (int) $left['max_height_mm'])) <=> (((int) $right['max_width_mm'] * (int) $right['max_height_mm']));
        }

        $left_span  = (((int) $left['max_width_mm'] - (int) $left['min_width_mm']) + ((int) $left['max_height_mm'] - (int) $left['min_height_mm']));
        $right_span = (((int) $right['max_width_mm'] - (int) $right['min_width_mm']) + ((int) $right['max_height_mm'] - (int) $right['min_height_mm']));

        if ($left_span === $right_span) {
            return (((int) $left['min_width_mm'] + (int) $left['min_height_mm'])) <=> (((int) $right['min_width_mm'] + (int) $right['min_height_mm']));
        }

        return $left_span <=> $right_span;
    }
}
