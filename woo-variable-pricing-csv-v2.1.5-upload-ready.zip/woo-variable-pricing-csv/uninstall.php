<?php

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

/**
 * Delete uploaded CSV files that were stored by the plugin.
 *
 * @return void
 */
function wvpc_delete_uploaded_csv_files() {
    global $wpdb;

    $meta_key       = '_wvpc_csv_file';
    $meta_values    = $wpdb->get_col($wpdb->prepare("SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s", $meta_key));
    $upload_dir     = wp_get_upload_dir();
    $uploads_basedir = isset($upload_dir['basedir']) ? wp_normalize_path(trailingslashit($upload_dir['basedir'])) : '';

    if (empty($meta_values) || empty($uploads_basedir)) {
        return;
    }

    foreach ($meta_values as $meta_value) {
        $stored_file = maybe_unserialize($meta_value);

        if (!is_array($stored_file) || empty($stored_file['file'])) {
            continue;
        }

        $file_path = wp_normalize_path((string) $stored_file['file']);

        if ('' === $file_path || 0 !== strpos($file_path, $uploads_basedir)) {
            continue;
        }

        if (!file_exists($file_path) || !is_file($file_path)) {
            continue;
        }

        if (function_exists('wp_delete_file')) {
            wp_delete_file($file_path);
        } else {
            @unlink($file_path);
        }
    }
}

/**
 * Remove the protected CSV directory created by the plugin when it is empty.
 *
 * @return void
 */
function wvpc_delete_uploaded_csv_directory() {
    $upload_dir = wp_get_upload_dir();
    $dir_path   = isset($upload_dir['basedir']) ? wp_normalize_path(trailingslashit($upload_dir['basedir']) . 'wvpc-csv') : '';

    if ('' === $dir_path || !is_dir($dir_path)) {
        return;
    }

    $protected_files = array(
        $dir_path . '/.htaccess',
        $dir_path . '/index.php',
    );

    foreach ($protected_files as $protected_file) {
        if (file_exists($protected_file) && is_file($protected_file)) {
            @unlink($protected_file);
        }
    }

    $remaining_files = glob($dir_path . '/*');

    if (!empty($remaining_files)) {
        return;
    }

    @rmdir($dir_path);
}

/**
 * Delete plugin product meta.
 *
 * @return void
 */
function wvpc_delete_post_meta() {
    $meta_keys = array(
        '_wvpc_enabled',
        '_wvpc_measure_settings',
        '_wvpc_pricing_rules',
        '_wvpc_last_import_summary',
        '_wvpc_csv_file',
        '_wvpc_attribute_surcharges',
    );

    foreach ($meta_keys as $meta_key) {
        delete_metadata('post', 0, $meta_key, '', true);
    }
}

/**
 * Delete order item meta left by the plugin.
 *
 * @return void
 */
function wvpc_delete_order_item_meta() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'woocommerce_order_itemmeta';
    $table      = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table_name));

    if ($table_name !== $table) {
        return;
    }

    // Keys use the internal constant names defined in WVPC_Pricing, not translated strings,
    // so cleanup works regardless of the store locale.
    $meta_keys     = array(
        '_wvpc_measurement_data',
        '_wvpc_width_mm',
        '_wvpc_height_mm',
        '_wvpc_rate_label',
        '_wvpc_surcharge_label',
    );
    $placeholders  = implode(', ', array_fill(0, count($meta_keys), '%s'));
    $prepared_sql  = $wpdb->prepare("DELETE FROM {$table_name} WHERE meta_key IN ({$placeholders})", $meta_keys);

    if ($prepared_sql) {
        $wpdb->query($prepared_sql);
    }
}

/**
 * Delete plugin transients used for admin notices.
 *
 * @return void
 */
function wvpc_delete_transients() {
    global $wpdb;

    $transient_like        = $wpdb->esc_like('_transient_wvpc_notice_') . '%';
    $timeout_transient_like = $wpdb->esc_like('_transient_timeout_wvpc_notice_') . '%';
    $prepared_sql          = $wpdb->prepare(
        "SELECT option_name FROM {$wpdb->options}
        WHERE option_name LIKE %s
        OR option_name LIKE %s",
        $transient_like,
        $timeout_transient_like
    );
    $option_names = $prepared_sql ? $wpdb->get_col($prepared_sql) : array();

    if (empty($option_names)) {
        return;
    }

    foreach ($option_names as $option_name) {
        delete_option($option_name);
    }
}

/**
 * Run cleanup for the current site.
 *
 * @return void
 */
function wvpc_uninstall_cleanup_site() {
    wvpc_delete_uploaded_csv_files();
    wvpc_delete_uploaded_csv_directory();
    wvpc_delete_post_meta();
    wvpc_delete_order_item_meta();
    wvpc_delete_transients();
}

if (is_multisite() && function_exists('get_sites')) {
    $site_ids = get_sites(
        array(
            'fields' => 'ids',
            'number' => 0,
        )
    );

    foreach ($site_ids as $site_id) {
        switch_to_blog((int) $site_id);
        wvpc_uninstall_cleanup_site();
        restore_current_blog();
    }
} else {
    wvpc_uninstall_cleanup_site();
}
