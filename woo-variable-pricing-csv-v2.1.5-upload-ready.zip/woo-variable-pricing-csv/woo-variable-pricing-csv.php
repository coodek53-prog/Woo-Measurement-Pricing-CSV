<?php
/**
 * Plugin Name: Woo Measurement Pricing CSV
 * Description: Calcula precios de productos variables de WooCommerce según ancho y alto en cm o mm usando una tabla de tarifas subida por CSV.
 * Version: 2.1.5
 * Author: Coodek
 * License: GPL-2.0-or-later
 * Text Domain: woo-variable-pricing-csv
 * Requires at least: 5.3
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 * WC tested up to: 9.9
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WVPC_VERSION', '2.1.5');
define('WVPC_PLUGIN_FILE', __FILE__);
define('WVPC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WVPC_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once WVPC_PLUGIN_DIR . 'includes/class-wvpc-admin.php';
require_once WVPC_PLUGIN_DIR . 'includes/class-wvpc-pricing.php';

class WVPC_Plugin {
    /**
     * Boot plugin hooks.
     *
     * @return void
     */
    public static function init() {
        add_action('plugins_loaded', array(__CLASS__, 'bootstrap'));
    }

    /**
     * Load plugin services when dependencies are ready.
     *
     * @return void
     */
    public static function bootstrap() {
        load_plugin_textdomain('woo-variable-pricing-csv', false, dirname(plugin_basename(__FILE__)) . '/languages');

        if (!class_exists('WooCommerce')) {
            if (is_admin()) {
                add_action('admin_notices', array(__CLASS__, 'render_missing_woocommerce_notice'));
            }

            return;
        }

        WVPC_Admin::init();
        WVPC_Pricing::init();
    }

    /**
     * Render a notice when WooCommerce is not active.
     *
     * @return void
     */
    public static function render_missing_woocommerce_notice() {
        if (!current_user_can('activate_plugins')) {
            return;
        }

        echo '<div class="notice notice-error"><p>';
        echo esc_html__('Woo Measurement Pricing CSV requiere que WooCommerce esté activo.', 'woo-variable-pricing-csv');
        echo '</p></div>';
    }
}

WVPC_Plugin::init();

/**
 * Declare compatibility with WooCommerce features.
 *
 * - custom_order_tables (HPOS): el plugin usa únicamente la API de
 *   WooCommerce (WC_Order_Item_Product::add_meta_data) y nunca consulta
 *   directamente las tablas posts/postmeta para pedidos, por lo que es
 *   totalmente compatible con el almacenamiento de pedidos de alto rendimiento.
 *
 * - product_block_editor: compatibilidad práctica mediante una pantalla
 *   dedicada del plugin para configurar medidas e importar el CSV incluso
 *   cuando el editor de bloques de WooCommerce está activo.
 */
add_action('before_woocommerce_init', function () {
    if (!class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        return;
    }

    if (!method_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil', 'declare_compatibility')) {
        return;
    }

    try {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', WVPC_PLUGIN_FILE, true);
    } catch (\Throwable $e) {
        // Ignore compatibility declaration failures so the plugin never breaks site bootstrap.
    }

    try {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('product_block_editor', WVPC_PLUGIN_FILE, true);
    } catch (\Throwable $e) {
        // Ignore compatibility declaration failures on WooCommerce versions that do not support this feature flag.
    }
});
